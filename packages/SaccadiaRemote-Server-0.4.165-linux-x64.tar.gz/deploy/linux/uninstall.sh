#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="/var/lib/saccadia-remote/server.env"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this uninstaller as root." >&2
    exit 1
fi

if command -v systemctl >/dev/null 2>&1; then
    systemctl disable --now saccadia-certificate-renewal.timer >/dev/null 2>&1 || true
fi

if [[ -f "${ENV_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${ENV_FILE}"
    compose_files=(-f "${SCRIPT_DIR}/compose.yaml")
    if [[ "${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_ENABLED:-false}" == "true" ]]; then
        compose_files+=(-f "${SCRIPT_DIR}/compose.management-certificate.yaml")
    fi
    if [[ -n "${SACCADIA_EDGE2_NODE_ID:-}" ]]; then
        compose_files+=(-f "${SCRIPT_DIR}/compose.second-edge.yaml")
    fi
    docker compose --env-file "${ENV_FILE}" "${compose_files[@]}" down
else
    docker compose -f "${SCRIPT_DIR}/compose.yaml" down
fi

echo "Containers were removed. Persistent data, certificate, images, and swap were retained."
