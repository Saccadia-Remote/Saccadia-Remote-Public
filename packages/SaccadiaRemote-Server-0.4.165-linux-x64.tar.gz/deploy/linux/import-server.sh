#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DATA_ROOT="/var/lib/saccadia-remote"
if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this import as root." >&2
    exit 1
fi
[[ $# -eq 1 ]] || { echo "Usage: $0 <input.srmigrate>" >&2; exit 1; }
bundle="$(readlink -f "$1")"
[[ -f "${bundle}" ]] || { echo "Migration bundle was not found: ${bundle}" >&2; exit 1; }
if [[ -d "${DATA_ROOT}" ]] && [[ -n "$(find "${DATA_ROOT}" -mindepth 1 -print -quit)" ]]; then
    echo "Refusing to overwrite existing server state at ${DATA_ROOT}." >&2
    exit 1
fi
for command in docker tar; do
    command -v "${command}" >/dev/null 2>&1 || {
        echo "Required command is unavailable: ${command}" >&2
        exit 1
    }
done

password="${SACCADIA_MIGRATION_PASSWORD:-}"
if [[ -z "${password}" ]]; then
    read -r -s -p "Migration bundle password: " password
    echo
fi
temporary="$(mktemp -d)"
cleanup() {
    rm -rf -- "${temporary}"
}
trap cleanup EXIT

# A new target may not have run the installer yet, so build only the current
# ServerService image required to authenticate and decrypt the bundle.
docker build -t saccadia-remote/server:local \
    -f "${SCRIPT_DIR}/Dockerfile.server" "${SCRIPT_DIR}/../.."
install -o 1654 -g 1654 -m 0600 "${bundle}" "${temporary}/server.srmigrate"
chown 1654:1654 "${temporary}"
chmod 0700 "${temporary}"
export SACCADIA_MIGRATION_PASSWORD="${password}"
docker run --rm --network none --read-only \
    --security-opt no-new-privileges:true --cap-drop ALL \
    --tmpfs /tmp:size=8m,mode=1777 \
    --env SACCADIA_MIGRATION_PASSWORD \
    --volume "${temporary}:/migration" \
    saccadia-remote/server:local \
    --decrypt-migration /migration/server.srmigrate /migration/server.tar.gz

while IFS= read -r entry; do
    case "${entry}" in
        saccadia-remote|saccadia-remote/*) ;;
        *) echo "Migration bundle contains an unsafe path: ${entry}" >&2; exit 1 ;;
    esac
    [[ "${entry}" != *"../"* ]] || {
        echo "Migration bundle contains path traversal." >&2
        exit 1
    }
done < <(tar -tzf "${temporary}/server.tar.gz")

tar -xzf "${temporary}/server.tar.gz" -C "${temporary}"
restored="${temporary}/saccadia-remote"
for required in \
    "server.env" \
    "secrets/saccadia-server.pfx" \
    "secrets/saccadia-coordinator-cluster.pfx"; do
    [[ -f "${restored}/${required}" ]] || {
        echo "Migration bundle is incomplete: ${required}" >&2
        exit 1
    }
done

install -d -m 0750 "$(dirname -- "${DATA_ROOT}")"
if [[ -d "${DATA_ROOT}" ]]; then
    rmdir "${DATA_ROOT}"
fi
mv "${restored}" "${DATA_ROOT}"
chmod 0600 "${DATA_ROOT}/server.env"
unset password SACCADIA_MIGRATION_PASSWORD
trap - EXIT
cleanup

echo "Server state imported to ${DATA_ROOT}."
echo "Install/start the current Saccadia bundle, then move the existing DNS name to this host."
