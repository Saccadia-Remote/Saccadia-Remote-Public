#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="/var/lib/saccadia-remote/server.env"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this command as root." >&2
    exit 1
fi
if [[ "$#" -ne 4 ]]; then
    echo "Usage: $0 <node-id> <cluster-pin> <wss-url> <signalling-tls-pin>" >&2
    exit 1
fi
NODE_ID="$1"
CLUSTER_PIN="${2^^}"
SIGNALLING_URL="$3"
SIGNALLING_PIN="${4^^}"

[[ "${NODE_ID}" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || {
    echo "NodeId contains unsupported characters." >&2
    exit 1
}
[[ "${CLUSTER_PIN}" =~ ^[0-9A-F]{64}$ ]] || {
    echo "Cluster pin must contain 64 hexadecimal characters." >&2
    exit 1
}
[[ "${SIGNALLING_PIN}" =~ ^[0-9A-F]{64}$ ]] || {
    echo "Signalling TLS pin must contain 64 hexadecimal characters." >&2
    exit 1
}
[[ "${SIGNALLING_URL}" =~ ^wss://[^[:space:]]+/ws$ ]] || {
    echo "Signalling URL must be an absolute wss:// URL ending in /ws." >&2
    exit 1
}
[[ -f "${ENV_FILE}" ]] || {
    echo "Coordinator environment does not exist: ${ENV_FILE}" >&2
    exit 1
}

# Rewrite only the four managed values. The temporary file stays beside the
# protected source so replacement is atomic and does not expose other secrets.
temporary_env="$(mktemp "${ENV_FILE}.XXXXXX")"
trap 'rm -f "${temporary_env}"' EXIT
awk '!/^SACCADIA_EDGE2_(NODE_ID|CLUSTER_PIN|SIGNALLING_URL|SIGNALLING_PIN)=/' \
    "${ENV_FILE}" > "${temporary_env}"
cat >> "${temporary_env}" <<EOF
SACCADIA_EDGE2_NODE_ID=${NODE_ID}
SACCADIA_EDGE2_CLUSTER_PIN=${CLUSTER_PIN}
SACCADIA_EDGE2_SIGNALLING_URL=${SIGNALLING_URL}
SACCADIA_EDGE2_SIGNALLING_PIN=${SIGNALLING_PIN}
EOF
chmod 0600 "${temporary_env}"
mv -f "${temporary_env}" "${ENV_FILE}"
trap - EXIT

docker compose --env-file "${ENV_FILE}" \
    -f "${SCRIPT_DIR}/compose.yaml" \
    -f "${SCRIPT_DIR}/compose.second-edge.yaml" \
    up -d --no-deps server

echo "Coordinator now allows ${NODE_ID}. The remote Edge may reconnect immediately."
