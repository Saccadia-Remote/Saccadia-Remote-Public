#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="/var/lib/saccadia-remote/server.env"
DATA_ROOT="/var/lib/saccadia-remote"
SERVICE_UID=1654
SERVICE_GID=1654
REQUESTED_MANAGEMENT_CERTIFICATE_PATH="${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PATH:-}"
REQUESTED_MANAGEMENT_CERTIFICATE_PASSWORD="${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PASSWORD:-}"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this installer as root." >&2
    exit 1
fi
# shellcheck source=accept-disclaimer.sh
source "${SCRIPT_DIR}/accept-disclaimer.sh"
saccadia_require_disclaimer_acceptance
for command in docker openssl swapon mkswap; do
    command -v "${command}" >/dev/null 2>&1 || {
        echo "Required command is unavailable: ${command}" >&2
        exit 1
    }
done
docker compose version >/dev/null 2>&1 || {
    echo "Docker Compose v2 is required." >&2
    exit 1
}

if [[ -f "${ENV_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${ENV_FILE}"
fi
if [[ -n "${REQUESTED_MANAGEMENT_CERTIFICATE_PATH}" ]]; then
    SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PATH="${REQUESTED_MANAGEMENT_CERTIFICATE_PATH}"
    SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PASSWORD="${REQUESTED_MANAGEMENT_CERTIFICATE_PASSWORD}"
fi
: "${SACCADIA_COORDINATOR_HOST:?Set the Coordinator IP or DNS name.}"
COORDINATOR_HOST="${SACCADIA_COORDINATOR_HOST}"
BOOTSTRAP_PORT="${SACCADIA_COORDINATOR_BOOTSTRAP_PORT:-5000}"
MANAGEMENT_PORT="${SACCADIA_COORDINATOR_MANAGEMENT_PORT:-5443}"
CLUSTER_PORT="${SACCADIA_COORDINATOR_CLUSTER_PORT:-7000}"
EDGE_NODE_ID="${SACCADIA_EDGE_NODE_ID:-edge-1}"
EDGE_SIGNALLING_HOST="${SACCADIA_EDGE_SIGNALLING_HOST:-${COORDINATOR_HOST}}"
EDGE_SIGNALLING_PORT="${SACCADIA_EDGE_SIGNALLING_PORT:-5100}"
CERTIFICATE_PASSWORD="${SACCADIA_CERTIFICATE_PASSWORD:-$(openssl rand -hex 24)}"
SIGNALLING_CERTIFICATE_PASSWORD="${SACCADIA_COORDINATOR_SIGNALLING_CERTIFICATE_PASSWORD:-${CERTIFICATE_PASSWORD}}"
MANAGEMENT_CERTIFICATE_ENABLED="${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_ENABLED:-false}"
MANAGEMENT_CERTIFICATE_PASSWORD="${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PASSWORD:-}"

saccadia_validate_host "Coordinator host" "${COORDINATOR_HOST}"
saccadia_validate_host "Edge signalling host" "${EDGE_SIGNALLING_HOST}"
saccadia_validate_port "Coordinator bootstrap port" "${BOOTSTRAP_PORT}"
saccadia_validate_port "Management port" "${MANAGEMENT_PORT}"
saccadia_validate_port "Coordinator cluster port" "${CLUSTER_PORT}"
saccadia_validate_port "Edge signalling port" "${EDGE_SIGNALLING_PORT}"
if [[ "${BOOTSTRAP_PORT}" == "${MANAGEMENT_PORT}" ||
      "${BOOTSTRAP_PORT}" == "${CLUSTER_PORT}" ||
      "${BOOTSTRAP_PORT}" == "${EDGE_SIGNALLING_PORT}" ||
      "${MANAGEMENT_PORT}" == "${CLUSTER_PORT}" ||
      "${MANAGEMENT_PORT}" == "${EDGE_SIGNALLING_PORT}" ||
      "${CLUSTER_PORT}" == "${EDGE_SIGNALLING_PORT}" ]]; then
    echo "Coordinator and local Edge TCP listeners must use different ports." >&2
    exit 1
fi
if [[ "${EDGE_NODE_ID}" != "${EDGE_NODE_ID//[^A-Za-z0-9._-]/}" ||
      ! "${EDGE_NODE_ID}" =~ ^[A-Za-z0-9] || ${#EDGE_NODE_ID} -gt 64 ]]; then
    echo "Edge node ID must contain 1..64 letters, digits, dots, underscores, or hyphens." >&2
    exit 1
fi
if [[ -n "${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PATH:-}" ]]; then
    [[ -n "${MANAGEMENT_CERTIFICATE_PASSWORD}" ]] || {
        echo "Set SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PASSWORD for the supplied management PFX." >&2
        exit 1
    }
    management_preflight_source="$(readlink -f "${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PATH}")"
    [[ -f "${management_preflight_source}" ]] || {
        echo "Coordinator management PFX was not found: ${management_preflight_source}" >&2
        exit 1
    }
    PFX_PASSWORD="${MANAGEMENT_CERTIFICATE_PASSWORD}" openssl pkcs12 \
        -in "${management_preflight_source}" -passin env:PFX_PASSWORD \
        -noout >/dev/null 2>&1 || {
        echo "Coordinator management PFX or its password is invalid." >&2
        exit 1
    }
    management_plan="operator PFX: ${management_preflight_source}"
else
    management_plan="Coordinator signalling certificate fallback"
fi
saccadia_warn_dns_resolution "Coordinator" "${COORDINATOR_HOST}"
if [[ "${EDGE_SIGNALLING_HOST}" != "${COORDINATOR_HOST}" ]]; then
    saccadia_warn_dns_resolution "Edge" "${EDGE_SIGNALLING_HOST}"
fi
saccadia_confirm_installation_plan \
    "Saccadia Remote Linux Server installation plan" \
    "Role: Coordinator + local Edge" \
    "Coordinator host: ${COORDINATOR_HOST}" \
    "Bootstrap: TCP/UDP ${BOOTSTRAP_PORT}" \
    "Management: TCP ${MANAGEMENT_PORT}" \
    "Cluster mTLS: TCP ${CLUSTER_PORT}" \
    "Local Edge: ${EDGE_NODE_ID} at wss://${EDGE_SIGNALLING_HOST}:${EDGE_SIGNALLING_PORT}/ws" \
    "Infrastructure certificates: installation-generated or existing identities" \
    "Management certificate: ${management_plan}" \
    "Persistent state: ${DATA_ROOT}"

install -d -m 0750 "${DATA_ROOT}"
install -d -o "${SERVICE_UID}" -g "${SERVICE_GID}" -m 0750 \
    "${DATA_ROOT}/server" "${DATA_ROOT}/edge"
install -d -o "${SERVICE_UID}" -g "${SERVICE_GID}" -m 0770 "${DATA_ROOT}/runtime"
install -d -o root -g "${SERVICE_GID}" -m 0750 "${DATA_ROOT}/secrets"

SWAP_FILE="/swapfile-saccadia"
if ! swapon --show=NAME --noheadings | tr -d ' ' | grep -Fxq "${SWAP_FILE}"; then
    if [[ ! -f "${SWAP_FILE}" ]]; then
        fallocate -l 512M "${SWAP_FILE}" || \
            dd if=/dev/zero of="${SWAP_FILE}" bs=1M count=512 status=progress
        chmod 0600 "${SWAP_FILE}"
        mkswap "${SWAP_FILE}" >/dev/null
    fi
    swapon "${SWAP_FILE}"
fi
grep -Fq "${SWAP_FILE} none swap sw 0 0" /etc/fstab ||
    printf '%s\n' "${SWAP_FILE} none swap sw 0 0" >> /etc/fstab

create_pfx() {
    local path="$1"
    local common_name="$2"
    local usage="$3"
    local san="$4"
    local password="$5"
    [[ -f "${path}" ]] && return
    local temporary_key temporary_cert
    temporary_key="$(mktemp)"
    temporary_cert="$(mktemp)"
    openssl req -x509 -newkey rsa:2048 -nodes -days 1825 \
        -subj "/CN=${common_name}" \
        -addext "keyUsage=critical,digitalSignature" \
        -addext "extendedKeyUsage=${usage}" \
        -addext "subjectAltName=${san}" \
        -keyout "${temporary_key}" -out "${temporary_cert}" >/dev/null 2>&1
    openssl pkcs12 -export \
        -inkey "${temporary_key}" -in "${temporary_cert}" \
        -out "${path}" -passout "pass:${password}"
    rm -f "${temporary_key}" "${temporary_cert}"
}

san_for_host() {
    if [[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        printf 'IP:%s,DNS:localhost' "$1"
    else
        printf 'DNS:%s,DNS:localhost' "$1"
    fi
}
coordinator_san="$(san_for_host "${COORDINATOR_HOST}")"
edge_san="$(san_for_host "${EDGE_SIGNALLING_HOST}")"
create_pfx "${DATA_ROOT}/secrets/saccadia-server.pfx" \
    "Saccadia Remote Coordinator Signalling" "serverAuth" \
    "${coordinator_san}" "${SIGNALLING_CERTIFICATE_PASSWORD}"
create_pfx "${DATA_ROOT}/secrets/saccadia-coordinator-cluster.pfx" \
    "Saccadia Remote Coordinator Cluster" "serverAuth" \
    "${coordinator_san}" "${CERTIFICATE_PASSWORD}"
create_pfx "${DATA_ROOT}/secrets/saccadia-edge-public.pfx" \
    "Saccadia Remote Edge Signalling" "serverAuth" \
    "${edge_san}" "${CERTIFICATE_PASSWORD}"
create_pfx "${DATA_ROOT}/secrets/saccadia-edge-cluster.pfx" \
    "Saccadia Remote Edge Cluster" "clientAuth" \
    "DNS:${EDGE_NODE_ID}" "${CERTIFICATE_PASSWORD}"

if [[ -n "${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PATH:-}" ]]; then
    [[ -n "${MANAGEMENT_CERTIFICATE_PASSWORD}" ]] || {
        echo "Set SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PASSWORD for the supplied management PFX." >&2
        exit 1
    }
    management_source="$(readlink -f "${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PATH}")"
    [[ -f "${management_source}" ]] || {
        echo "Coordinator management PFX was not found: ${management_source}" >&2
        exit 1
    }
    # Parse the PFX before installing it. Runtime performs the complete SAN,
    # validity and serverAuth validation before opening the management listener.
    PFX_PASSWORD="${MANAGEMENT_CERTIFICATE_PASSWORD}" openssl pkcs12 \
        -in "${management_source}" -passin env:PFX_PASSWORD -noout >/dev/null 2>&1 || {
        echo "Coordinator management PFX or its password is invalid." >&2
        exit 1
    }
    management_target="${DATA_ROOT}/secrets/saccadia-management.pfx"
    if [[ "${management_source}" != "${management_target}" ]]; then
        install -o root -g "${SERVICE_GID}" -m 0640 "${management_source}" \
            "${management_target}"
    fi
    printf '%s' "${MANAGEMENT_CERTIFICATE_PASSWORD}" > \
        "${DATA_ROOT}/secrets/saccadia-management.pfx.password"
    MANAGEMENT_CERTIFICATE_ENABLED=true
elif [[ ! -f "${DATA_ROOT}/secrets/saccadia-management.pfx" ]]; then
    MANAGEMENT_CERTIFICATE_ENABLED=false
    MANAGEMENT_CERTIFICATE_PASSWORD=""
fi

public_key_pin() {
    local path="$1" password="$2"
    openssl pkcs12 -in "${path}" -passin "pass:${password}" \
        -nokeys 2>/dev/null |
        openssl x509 -pubkey -noout 2>/dev/null |
        openssl pkey -pubin -outform DER 2>/dev/null |
        openssl dgst -sha256 -hex |
        awk '{print toupper($2)}'
}

COORDINATOR_CLUSTER_PIN="$(public_key_pin \
    "${DATA_ROOT}/secrets/saccadia-coordinator-cluster.pfx" "${CERTIFICATE_PASSWORD}")"
EDGE_SIGNALLING_PIN="$(public_key_pin \
    "${DATA_ROOT}/secrets/saccadia-edge-public.pfx" "${CERTIFICATE_PASSWORD}")"
EDGE_CLUSTER_PIN="$(public_key_pin \
    "${DATA_ROOT}/secrets/saccadia-edge-cluster.pfx" "${CERTIFICATE_PASSWORD}")"

umask 077
cat > "${ENV_FILE}" <<EOF
SACCADIA_COORDINATOR_HOST=${COORDINATOR_HOST}
SACCADIA_COORDINATOR_BOOTSTRAP_PORT=${BOOTSTRAP_PORT}
SACCADIA_COORDINATOR_MANAGEMENT_PORT=${MANAGEMENT_PORT}
SACCADIA_COORDINATOR_CLUSTER_PORT=${CLUSTER_PORT}
SACCADIA_RELAY_LIMIT_MBPS=${SACCADIA_RELAY_LIMIT_MBPS:-50}
SACCADIA_MAX_RELAY_CHANNELS=${SACCADIA_MAX_RELAY_CHANNELS:-4}
SACCADIA_LOGGING_ENABLED=${SACCADIA_LOGGING_ENABLED:-false}
SACCADIA_CERTIFICATE_PASSWORD=${CERTIFICATE_PASSWORD}
SACCADIA_COORDINATOR_SIGNALLING_CERTIFICATE_PASSWORD=${SIGNALLING_CERTIFICATE_PASSWORD}
SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_ENABLED=${MANAGEMENT_CERTIFICATE_ENABLED}
SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PASSWORD=${MANAGEMENT_CERTIFICATE_PASSWORD}
SACCADIA_EDGE_NODE_ID=${EDGE_NODE_ID}
SACCADIA_EDGE_SIGNALLING_HOST=${EDGE_SIGNALLING_HOST}
SACCADIA_EDGE_SIGNALLING_PORT=${EDGE_SIGNALLING_PORT}
SACCADIA_COORDINATOR_CLUSTER_PIN=${COORDINATOR_CLUSTER_PIN}
SACCADIA_EDGE_CLUSTER_PIN=${EDGE_CLUSTER_PIN}
SACCADIA_EDGE_SIGNALLING_PIN=${EDGE_SIGNALLING_PIN}
EOF
if [[ -n "${SACCADIA_EDGE2_NODE_ID:-}" ]]; then
    cat >> "${ENV_FILE}" <<EOF
SACCADIA_EDGE2_NODE_ID=${SACCADIA_EDGE2_NODE_ID}
SACCADIA_EDGE2_CLUSTER_PIN=${SACCADIA_EDGE2_CLUSTER_PIN}
SACCADIA_EDGE2_SIGNALLING_URL=${SACCADIA_EDGE2_SIGNALLING_URL}
SACCADIA_EDGE2_SIGNALLING_PIN=${SACCADIA_EDGE2_SIGNALLING_PIN}
EOF
fi
printf '%s' "${SIGNALLING_CERTIFICATE_PASSWORD}" > \
    "${DATA_ROOT}/secrets/saccadia-server.pfx.password"
for password_file in \
    "${DATA_ROOT}/secrets/saccadia-coordinator-cluster.pfx.password" \
    "${DATA_ROOT}/secrets/saccadia-edge-public.pfx.password" \
    "${DATA_ROOT}/secrets/saccadia-edge-cluster.pfx.password"; do
    printf '%s' "${CERTIFICATE_PASSWORD}" > "${password_file}"
done
cat > "${DATA_ROOT}/certificate-renewal.json" <<EOF
{
  "version": 1,
  "renewBeforeDays": 180,
  "certificates": [
    {
      "role": "CoordinatorSignallingTLS",
      "certificatePath": "/certificates/saccadia-server.pfx",
      "passwordFile": "/certificates/saccadia-server.pfx.password",
      "manifestPath": "/server-data/data/identity/coordinator-public-certificate.json",
      "source": "installation-generated",
      "restartGroup": "server",
      "unixOwnerId": 0,
      "unixGroupId": ${SERVICE_GID},
      "unixManifestOwnerId": ${SERVICE_UID},
      "unixManifestGroupId": ${SERVICE_GID}
    },
    {
      "role": "CoordinatorClusterTLS",
      "certificatePath": "/certificates/saccadia-coordinator-cluster.pfx",
      "passwordFile": "/certificates/saccadia-coordinator-cluster.pfx.password",
      "manifestPath": "/server-data/data/identity/coordinator-cluster-certificate.json",
      "source": "installation-generated",
      "restartGroup": "server",
      "unixOwnerId": 0,
      "unixGroupId": ${SERVICE_GID},
      "unixManifestOwnerId": ${SERVICE_UID},
      "unixManifestGroupId": ${SERVICE_GID}
    },
    {
      "role": "EdgeSignallingTLS",
      "certificatePath": "/certificates/saccadia-edge-public.pfx",
      "passwordFile": "/certificates/saccadia-edge-public.pfx.password",
      "manifestPath": "/edge-data/identity/edge-public-certificate.json",
      "source": "installation-generated",
      "restartGroup": "edge",
      "unixOwnerId": 0,
      "unixGroupId": ${SERVICE_GID},
      "unixManifestOwnerId": ${SERVICE_UID},
      "unixManifestGroupId": ${SERVICE_GID}
    },
    {
      "role": "EdgeClusterTLS",
      "certificatePath": "/certificates/saccadia-edge-cluster.pfx",
      "passwordFile": "/certificates/saccadia-edge-cluster.pfx.password",
      "manifestPath": "/edge-data/identity/edge-cluster-certificate.json",
      "source": "installation-generated",
      "restartGroup": "edge",
      "unixOwnerId": 0,
      "unixGroupId": ${SERVICE_GID},
      "unixManifestOwnerId": ${SERVICE_UID},
      "unixManifestGroupId": ${SERVICE_GID}
    }
  ]
}
EOF
chown root:"${SERVICE_GID}" "${DATA_ROOT}"/secrets/*.pfx
chown root:"${SERVICE_GID}" "${DATA_ROOT}"/secrets/*.password
chmod 0640 "${DATA_ROOT}"/secrets/*.pfx "${DATA_ROOT}"/secrets/*.password
chmod 0600 "${ENV_FILE}"
chmod 0640 "${DATA_ROOT}/certificate-renewal.json"

compose_files=(-f "${SCRIPT_DIR}/compose.yaml")
if [[ "${MANAGEMENT_CERTIFICATE_ENABLED}" == "true" ]]; then
    compose_files+=(-f "${SCRIPT_DIR}/compose.management-certificate.yaml")
fi
if [[ -n "${SACCADIA_EDGE2_NODE_ID:-}" ]]; then
    compose_files+=(-f "${SCRIPT_DIR}/compose.second-edge.yaml")
fi

# The package is commonly extracted over an existing installation. Retaining old Linux
# client archives in this Docker context adds every prior release to the server image.
# Read the current package manifest and verify its archive before removing older ones.
linux_template_dir="${SCRIPT_DIR}/artifacts/server/client-templates/linux-x64"
linux_template_name="$(sed -n 's/^[[:space:]]*"templateFileName":[[:space:]]*"\([^"]*\)".*/\1/p' \
    "${linux_template_dir}/package.json")"
if [[ ! "${linux_template_name}" =~ ^SaccadiaRemote-[0-9]+\.[0-9]+\.[0-9]+-linux-x64\.tar\.gz$ ||
      ! -s "${linux_template_dir}/${linux_template_name}" ]]; then
    echo "The current Linux client template is missing or invalid." >&2
    exit 1
fi
find "${linux_template_dir}" -maxdepth 1 -type f \
    -name 'SaccadiaRemote-*-linux-x64.tar.gz' \
    ! -name "${linux_template_name}" -delete

docker compose --env-file "${ENV_FILE}" "${compose_files[@]}" build --pull
docker compose --env-file "${ENV_FILE}" "${compose_files[@]}" up -d --remove-orphans

if command -v systemctl >/dev/null 2>&1; then
    chmod 0755 "${SCRIPT_DIR}/renew-certificates.sh"
    install -m 0644 "${SCRIPT_DIR}/systemd/saccadia-certificate-renewal.service" \
        /etc/systemd/system/saccadia-certificate-renewal.service
    install -m 0644 "${SCRIPT_DIR}/systemd/saccadia-certificate-renewal.timer" \
        /etc/systemd/system/saccadia-certificate-renewal.timer
    systemctl daemon-reload
    systemctl enable --now saccadia-certificate-renewal.timer
fi

echo "Saccadia Remote Coordinator and Edge are starting."
echo "Bootstrap:   wss://${COORDINATOR_HOST}:${BOOTSTRAP_PORT}/bootstrap"
echo "Management:  https://${COORDINATOR_HOST}:${MANAGEMENT_PORT}/status"
echo "Edge:        wss://${EDGE_SIGNALLING_HOST}:${EDGE_SIGNALLING_PORT}/ws"
echo "Cluster:     ${COORDINATOR_HOST}:${CLUSTER_PORT}/tcp (mTLS only)"
echo "Coordinator cluster pin: ${COORDINATOR_CLUSTER_PIN}"
echo "Edge cluster pin:        ${EDGE_CLUSTER_PIN}"
echo "Edge signalling TLS pin: ${EDGE_SIGNALLING_PIN}"
