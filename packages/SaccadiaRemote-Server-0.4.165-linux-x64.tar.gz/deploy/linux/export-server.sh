#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DATA_ROOT="/var/lib/saccadia-remote"
ENV_FILE="${DATA_ROOT}/server.env"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this export as root." >&2
    exit 1
fi
[[ $# -eq 1 ]] || { echo "Usage: $0 <output.srmigrate>" >&2; exit 1; }
[[ -f "${ENV_FILE}" ]] || { echo "Server state was not found at ${DATA_ROOT}." >&2; exit 1; }
for command in docker tar readlink; do
    command -v "${command}" >/dev/null 2>&1 || {
        echo "Required command is unavailable: ${command}" >&2
        exit 1
    }
done

output="$(readlink -m "$1")"
[[ ! -e "${output}" ]] || { echo "Output already exists: ${output}" >&2; exit 1; }
case "${output}" in
    "${DATA_ROOT}"|"${DATA_ROOT}"/*)
        echo "Migration bundle must be stored outside ${DATA_ROOT}." >&2
        exit 1
        ;;
esac
install -d -m 0700 "$(dirname -- "${output}")"

password="${SACCADIA_MIGRATION_PASSWORD:-}"
if [[ -z "${password}" ]]; then
    read -r -s -p "Migration bundle password: " password
    echo
    read -r -s -p "Repeat password: " repeated
    echo
    [[ "${password}" == "${repeated}" ]] || { echo "Passwords do not match." >&2; exit 1; }
fi
[[ ${#password} -ge 12 ]] || { echo "Migration password must contain at least 12 characters." >&2; exit 1; }

# shellcheck disable=SC1090
source "${ENV_FILE}"
compose_files=(-f "${SCRIPT_DIR}/compose.yaml")
if [[ -n "${SACCADIA_EDGE2_NODE_ID:-}" ]]; then
    compose_files+=(-f "${SCRIPT_DIR}/compose.second-edge.yaml")
fi
restart_required=false
temporary="$(mktemp -d)"
restart_services() {
    if [[ "${restart_required}" == true ]]; then
        docker compose --env-file "${ENV_FILE}" "${compose_files[@]}" start >/dev/null
    fi
}
cleanup() {
    rm -rf -- "${temporary}"
    restart_services
}
trap cleanup EXIT

# SQLite, certificate manifests and configuration must describe one instant.
# A brief controlled stop is safer than copying a live WAL database.
docker compose --env-file "${ENV_FILE}" "${compose_files[@]}" stop >/dev/null
restart_required=true
umask 077
# Personalized download files are a derived cache and are rebuilt from the
# preserved templates/identity database after import. Excluding the cache keeps
# migration bundles small without changing server or client identities.
tar --exclude='saccadia-remote/server/generated-downloads' \
    -C /var/lib -czf "${temporary}/server.tar.gz" saccadia-remote

# Reuse the cross-platform ServerService migration format: PBKDF2-SHA256,
# AES-256-CBC and encrypt-then-HMAC-SHA256. The transient container has no
# network and can access only the staging directory.
chown -R 1654:1654 "${temporary}"
export SACCADIA_MIGRATION_PASSWORD="${password}"
docker run --rm --network none --read-only \
    --security-opt no-new-privileges:true --cap-drop ALL \
    --tmpfs /tmp:size=8m,mode=1777 \
    --env SACCADIA_MIGRATION_PASSWORD \
    --volume "${temporary}:/migration" \
    saccadia-remote/server:local \
    --encrypt-migration /migration/server.tar.gz /migration/server.srmigrate
install -o root -g root -m 0600 "${temporary}/server.srmigrate" "${output}"

restart_services
restart_required=false
trap - EXIT
unset password repeated SACCADIA_MIGRATION_PASSWORD
rm -rf -- "${temporary}"
echo "Encrypted server migration bundle created: ${output}"
echo "Keep its password separately. The authenticated bundle preserves the domain TLS key and all pins."
