#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="/var/lib/saccadia-remote/server-relay.env"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this uninstaller as root." >&2
    exit 1
fi
if [[ -f "${ENV_FILE}" ]]; then
    docker compose --env-file "${ENV_FILE}" -f "${SCRIPT_DIR}/compose.server-relay.yaml" down
else
    docker compose -f "${SCRIPT_DIR}/compose.server-relay.yaml" down
fi
echo "Saccadia Remote ServerRelay container was stopped. Persistent identity is preserved."
