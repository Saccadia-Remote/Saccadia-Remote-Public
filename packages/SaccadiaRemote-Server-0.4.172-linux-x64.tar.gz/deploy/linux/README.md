# Saccadia Remote Server for Linux

The full-node deployment runs two independent containers:

- `server`: Coordinator bootstrap, logical signalling, the management console,
  SQLite identity storage, and server-specific client package generation.
- `edge`: direct client WSS ownership and batched liveness transport over one
  multiplexed mTLS stream to Coordinator.

The default ports are TCP/UDP 5000 for `CoordinatorBootstrap` and rendezvous,
TCP 5443 for `CoordinatorManagementConsole`, TCP 5100 for `EdgeSignalling`, and
TCP 7000 for the mTLS-only cluster listener. Standalone server relays use UDP
5001 by default when installed separately.
The long-lived client WSS is accepted by Edge, not Coordinator.

## Certificate roles

The distributed server uses four pinned infrastructure identities:

- `CoordinatorSignallingTLS` authenticates client bootstrap.
- `CoordinatorClusterTLS` authenticates Coordinator to Edge and protects the
  cluster listener.
- `EdgeSignallingTLS` authenticates an Edge to clients assigned to it.
- `EdgeClusterTLS` authenticates an allowed Edge to Coordinator.

Each standard installation creates unique persistent PFX identities. The
installer also installs `saccadia-cert`, and a daily systemd timer renews
installation-generated certificates before expiry with the same private key.
This extends validity without changing any configured client or cluster pin.
Operator-managed PFX files are reported but never self-issued by this tool.

`CoordinatorManagementConsole` may use its own operator-provided browser
certificate. If it is not configured, it deliberately falls back to
`CoordinatorSignallingTLS`. The CA-issued certificate used by an optional Nginx
landing page is outside the server distribution and is not used as a cluster
identity.

## Build and install a full node

On Windows, build the bundle with:

```powershell
.\scripts\Publish-LinuxDocker.ps1 -PublicHost server.example.com
```

Extract `publish/SaccadiaRemote.Server-linux-x64.tar.gz` into
`/opt/saccadia-remote`, then run as root:

```bash
SACCADIA_COORDINATOR_HOST=server.example.com \
  bash /opt/saccadia-remote/deploy/linux/install.sh
```

To configure a separate certificate for the browser-facing management console:

```bash
SACCADIA_COORDINATOR_HOST=server.example.com \
SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PATH=/root/management.pfx \
SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_PASSWORD='<pfx-password>' \
  bash /opt/saccadia-remote/deploy/linux/install.sh
```

Re-running the installer preserves identities, pins, the Edge allowlist,
database, and generated client state. It does not rotate an established key.

## Install a standalone ServerRelay

Download the ServerRelay package from the authenticated Coordinator status page,
extract it on the relay host, and run:

```bash
SACCADIA_COORDINATOR_URL=https://server.example.com:5000 \
SACCADIA_RELAY_PUBLIC_HOST=relay.example.com \
  bash /opt/saccadia-remote/deploy/linux/install-server-relay.sh
```

The installer prints a stable relay fingerprint. Add that fingerprint and the
expected relay source IP/CIDR on the Coordinator status page before the
Coordinator will advertise the relay. Re-running the installer updates binaries
without changing the relay identity.

## Inspect or renew certificates

The daily timer runs automatically. An administrator may also run it or inspect
the canonical roles manually:

```bash
systemctl start saccadia-certificate-renewal.service
docker run --rm --user 0:0 --entrypoint dotnet \
  -v /var/lib/saccadia-remote/secrets:/certificates \
  -v /var/lib/saccadia-remote/server:/server-data \
  -v /var/lib/saccadia-remote/edge:/edge-data \
  -v /var/lib/saccadia-remote/certificate-renewal.json:/config/certificate-renewal.json:ro \
  saccadia-remote/server:local \
  /app/tools/certificates/saccadia-cert.dll status \
  --config /config/certificate-renewal.json
```

The renewal operation keeps one `.previous` PFX backup and restarts only the
service group whose certificate changed. Key rotation is intentionally a
separate, coordinated procedure because it changes pins.

## Migration

Export an encrypted consistent snapshot before moving the domain or IP:

```bash
bash /opt/saccadia-remote/deploy/linux/export-server.sh /root/server.srmigrate
bash /opt/saccadia-remote/deploy/linux/import-server.sh /root/server.srmigrate
```

The authenticated bundle contains infrastructure and optional management PFX
files, pin manifests, configuration, allowlists, and SQLite data. Restoring this
unit keeps the existing pins; independently installed Edge nodes retain their
own persistent identities.

To stop the full-node containers while retaining persistent state:

```bash
bash /opt/saccadia-remote/deploy/linux/uninstall.sh
```

## Install a second Edge

On another Linux server:

```bash
SACCADIA_EDGE_SIGNALLING_HOST=edge2.example.com \
SACCADIA_EDGE_NODE_ID=edge-2 \
SACCADIA_COORDINATOR_HOST=server.example.com \
SACCADIA_COORDINATOR_CLUSTER_PIN=<pin-from-coordinator-status> \
  bash /opt/saccadia-remote/deploy/linux/install-edge.sh
```

Interactive installation prints `DISCLAIMER.md` and requires the exact responses
`I ACCEPT` and `INSTALL`. For deliberate unattended automation, set both
`SACCADIA_ACCEPT_DISCLAIMER=YES` and `SACCADIA_CONFIRM_INSTALLATION=YES`.

The installer prints the canonical `NodeId`, cluster pin,
`SignallingWebSocketUrl`, and `SignallingTlsPublicKeyPin`. Register that exact
tuple on Coordinator:

```bash
bash /opt/saccadia-remote/deploy/linux/register-second-edge.sh \
  edge-2 <edge-cluster-pin> wss://edge2.example.com:5100/ws <edge-signalling-pin>
```

The same roles and PFX configuration are supported by the Windows ServerService
and EdgeService installers. Their daily scheduled tasks use the bundled
`saccadia-cert.exe` utility and restart only the affected Windows service.

## Public privacy policy

Every Coordinator exposes `/privacy` without a management login. It is available
on the management HTTPS listener and on the bootstrap HTTPS listener. Client
settings link to the connected server's authenticated management origin; before
connection they use the selected bootstrap origin. Browser certificate validation
still applies. For a public store listing, use the management URL with a valid,
publicly trusted certificate.

The bundled `wwwroot/privacy-template.html` contains no operator's personal data.
Set your public privacy contact in `data/privacy-contact.txt` under the persistent
server storage root. In the standard Linux deployment this is
`/var/lib/saccadia-remote/server/data/privacy-contact.txt` on the host. The server
HTML-encodes the contact and reads it on each request. Make the file readable by
the server container user (UID 1654).

For processing or retention practices different from the standard distribution,
place your complete UTF-8 HTML policy in `data/privacy.html` in the same persistent
root. The optional `{{OPERATOR_CONTACT}}` token is replaced with the configured
contact paragraph. Supply a normal standalone HTML page; the endpoint disallows
scripts, embedded resources and forms. Operator files survive application upgrades
and must not be included in generic server/client distribution packages.
