#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="/var/lib/saccadia-remote/server-relay.env"
DATA_ROOT="/var/lib/saccadia-remote"
SERVICE_UID=1654
SERVICE_GID=1654

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this installer as root." >&2
    exit 1
fi
# shellcheck source=accept-disclaimer.sh
source "${SCRIPT_DIR}/accept-disclaimer.sh"
saccadia_require_disclaimer_acceptance
for command in docker; do
    command -v "${command}" >/dev/null 2>&1 || {
        echo "Required command is unavailable: ${command}" >&2
        exit 1
    }
done
docker compose version >/dev/null 2>&1 || {
    echo "Docker Compose v2 is required." >&2
    exit 1
}

if [[ -f "${SCRIPT_DIR}/../../relay.env" ]]; then
    # shellcheck disable=SC1090
    source "${SCRIPT_DIR}/../../relay.env"
fi
if [[ -f "${ENV_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${ENV_FILE}"
fi
: "${SACCADIA_COORDINATOR_URL:?Set Coordinator bootstrap URL.}"
: "${SACCADIA_RELAY_PUBLIC_HOST:?Set the relay public IP or DNS name.}"
RELAY_PORT="${SACCADIA_RELAY_PORT:-5001}"
RELAY_LIMIT="${SACCADIA_RELAY_LIMIT_MBPS:-50}"

saccadia_validate_host "Relay public host" "${SACCADIA_RELAY_PUBLIC_HOST}"
saccadia_validate_port "Relay UDP port" "${RELAY_PORT}"
saccadia_confirm_installation_plan \
    "Saccadia Remote Linux ServerRelay installation plan" \
    "Role: independently registered server relay" \
    "Coordinator: ${SACCADIA_COORDINATOR_URL}" \
    "Coordinator TLS pin: ${SACCADIA_COORDINATOR_TLS_PIN:-system trust}" \
    "Public relay: ${SACCADIA_RELAY_PUBLIC_HOST}:${RELAY_PORT}/udp" \
    "Traffic limit: ${RELAY_LIMIT} Mbit/s" \
    "Persistent state: ${DATA_ROOT}/server-relay"

install -d -m 0750 "${DATA_ROOT}"
install -d -o "${SERVICE_UID}" -g "${SERVICE_GID}" -m 0750 \
    "${DATA_ROOT}/server-relay" "${DATA_ROOT}/server-relay-runtime"

umask 077
cat > "${ENV_FILE}" <<EOF
SACCADIA_COORDINATOR_URL=${SACCADIA_COORDINATOR_URL}
SACCADIA_COORDINATOR_TLS_PIN=${SACCADIA_COORDINATOR_TLS_PIN:-}
SACCADIA_RELAY_PUBLIC_HOST=${SACCADIA_RELAY_PUBLIC_HOST}
SACCADIA_RELAY_PORT=${RELAY_PORT}
SACCADIA_RELAY_TRANSPORT=${SACCADIA_RELAY_TRANSPORT:-udp}
SACCADIA_RELAY_LIMIT_MBPS=${RELAY_LIMIT}
SACCADIA_LOGGING_ENABLED=${SACCADIA_LOGGING_ENABLED:-false}
EOF
chmod 0600 "${ENV_FILE}"

docker compose --env-file "${ENV_FILE}" -f "${SCRIPT_DIR}/compose.server-relay.yaml" build --pull
docker compose --env-file "${ENV_FILE}" -f "${SCRIPT_DIR}/compose.server-relay.yaml" up -d --remove-orphans

fingerprint="$(docker compose --env-file "${ENV_FILE}" -f "${SCRIPT_DIR}/compose.server-relay.yaml" run --rm server-relay -fingerprint)"
echo "Saccadia Remote ServerRelay is installed and running."
echo "Fingerprint: ${fingerprint}"
echo "Allow this fingerprint on Coordinator for relay source IP/CIDR before it can be used."
