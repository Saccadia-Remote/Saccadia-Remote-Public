function Assert-SaccadiaDisclaimerAcceptance {
    [CmdletBinding()]
    param(
        [switch] $AcceptDisclaimer,
        [string] $DisclaimerPath = ""
    )

    if ([string]::IsNullOrWhiteSpace($DisclaimerPath)) {
        $packageNotice = Join-Path $PSScriptRoot "DISCLAIMER.md"
        $repositoryNotice = Join-Path $PSScriptRoot "..\PublicGit\DISCLAIMER.md"
        $DisclaimerPath = if (Test-Path -LiteralPath $packageNotice -PathType Leaf) {
            $packageNotice
        } else {
            $repositoryNotice
        }
    }

    if ($AcceptDisclaimer) {
        Write-Host "Disclaimer accepted: the software is installed as-is and at the administrator's risk."
        return
    }

    if (Test-Path -LiteralPath $DisclaimerPath -PathType Leaf) {
        Write-Host (Get-Content -LiteralPath $DisclaimerPath -Raw)
    }
    throw "Installation stopped. Read DISCLAIMER.md and rerun with -AcceptDisclaimer to accept the as-is software terms and responsibility for possible consequences."
}
