#!/usr/bin/env bash

# Installation must be an explicit administrator decision. This check runs
# before certificates, persistent directories, firewall-facing containers, or
# systemd units are created. Automated installs opt in through one exact value.
saccadia_require_disclaimer_acceptance() {
    if [[ "${SACCADIA_ACCEPT_DISCLAIMER:-}" == "YES" ]]; then
        echo "Disclaimer accepted: installing the software as-is at the administrator's risk."
        return 0
    fi

    local package_root repository_root notice
    package_root="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
    repository_root="${package_root}/PublicGit"
    for notice in "${package_root}/DISCLAIMER.md" "${repository_root}/DISCLAIMER.md"; do
        if [[ -f "${notice}" ]]; then
            sed -n '1,220p' "${notice}"
            break
        fi
    done
    echo >&2
    echo "Installation stopped. Read DISCLAIMER.md and rerun with SACCADIA_ACCEPT_DISCLAIMER=YES to accept the as-is software terms and responsibility for possible consequences." >&2
    return 1
}
