#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-full}"

renew_full_node() {
    local data_root="/var/lib/saccadia-remote"
    local env_file="${data_root}/server.env"
    local marker="${data_root}/runtime/certificate-renewal.changed"
    rm -f -- "${marker}"
    docker run --rm --user 0:0 --entrypoint dotnet \
        -v "${data_root}/secrets:/certificates" \
        -v "${data_root}/server:/server-data" \
        -v "${data_root}/edge:/edge-data" \
        -v "${data_root}/certificate-renewal.json:/config/certificate-renewal.json:ro" \
        -v "${data_root}/runtime:/result" \
        saccadia-remote/server:local \
        /app/tools/certificates/saccadia-cert.dll renew-due \
        --config /config/certificate-renewal.json \
        --changed-marker /result/certificate-renewal.changed
    [[ -f "${marker}" ]] || return

    local compose_files=(-f "${SCRIPT_DIR}/compose.yaml")
    # shellcheck disable=SC1090
    source "${env_file}"
    if [[ "${SACCADIA_COORDINATOR_MANAGEMENT_CERTIFICATE_ENABLED:-false}" == "true" ]]; then
        compose_files+=(-f "${SCRIPT_DIR}/compose.management-certificate.yaml")
    fi
    if [[ -n "${SACCADIA_EDGE2_NODE_ID:-}" ]]; then
        compose_files+=(-f "${SCRIPT_DIR}/compose.second-edge.yaml")
    fi
    while IFS= read -r group; do
        case "${group}" in
            server|edge)
                docker compose --env-file "${env_file}" \
                    "${compose_files[@]}" restart "${group}"
                ;;
        esac
    done < "${marker}"
    rm -f -- "${marker}"
}

renew_edge_node() {
    local data_root="/var/lib/saccadia-remote-edge"
    local env_file="${data_root}/edge.env"
    local marker="${data_root}/certificate-renewal.changed"
    rm -f -- "${marker}"
    docker run --rm --user 0:0 --entrypoint dotnet \
        -v "${data_root}/secrets:/certificates" \
        -v "${data_root}/data:/edge-data" \
        -v "${data_root}/certificate-renewal.json:/config/certificate-renewal.json:ro" \
        -v "${data_root}:/result" \
        saccadia-remote/edge:local \
        /app/tools/certificates/saccadia-cert.dll renew-due \
        --config /config/certificate-renewal.json \
        --changed-marker /result/certificate-renewal.changed
    if [[ -f "${marker}" ]] && grep -Fxq edge "${marker}"; then
        docker compose --env-file "${env_file}" \
            -f "${SCRIPT_DIR}/compose.edge.yaml" restart edge
    fi
    rm -f -- "${marker}"
}

case "${MODE}" in
    full) renew_full_node ;;
    edge) renew_edge_node ;;
    *) echo "Usage: $0 [full|edge]" >&2; exit 2 ;;
esac
