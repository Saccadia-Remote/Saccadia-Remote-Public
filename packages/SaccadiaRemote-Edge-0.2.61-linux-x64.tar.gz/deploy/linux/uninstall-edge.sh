#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="/var/lib/saccadia-remote-edge/edge.env"
if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this uninstaller as root." >&2
    exit 1
fi
if command -v systemctl >/dev/null 2>&1; then
    systemctl disable --now saccadia-edge-certificate-renewal.timer >/dev/null 2>&1 || true
fi
if [[ -f "${ENV_FILE}" ]]; then
    docker compose --env-file "${ENV_FILE}" -f "${SCRIPT_DIR}/compose.edge.yaml" down
else
    docker compose -f "${SCRIPT_DIR}/compose.edge.yaml" down
fi
echo "Edge container was removed. Persistent identities and data were retained."
