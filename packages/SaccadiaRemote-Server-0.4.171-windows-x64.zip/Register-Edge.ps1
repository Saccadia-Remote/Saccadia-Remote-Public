[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string] $NodeId,
    [Parameter(Mandatory = $true)] [string] $ClusterPublicKeyPin,
    [Parameter(Mandatory = $true)] [string] $SignallingWebSocketUrl,
    [Parameter(Mandatory = $true)] [string] $SignallingTlsPublicKeyPin,
    [string] $ConfigurationPath = "",
    [string] $ServiceName = "SaccadiaRemoteServerService"
)

$ErrorActionPreference = "Stop"
if ($NodeId -notmatch '^[A-Za-z0-9._-]{1,64}$') {
    throw "NodeId contains unsupported characters."
}
$ClusterPublicKeyPin = $ClusterPublicKeyPin.ToUpperInvariant()
$SignallingTlsPublicKeyPin = $SignallingTlsPublicKeyPin.ToUpperInvariant()
if ($ClusterPublicKeyPin -notmatch '^[0-9A-F]{64}$') {
    throw "ClusterPublicKeyPin must contain 64 hexadecimal characters."
}
if ($SignallingTlsPublicKeyPin -notmatch '^[0-9A-F]{64}$') {
    throw "SignallingTlsPublicKeyPin must contain 64 hexadecimal characters."
}
$signallingUri = $null
if (-not [Uri]::TryCreate($SignallingWebSocketUrl, [UriKind]::Absolute, [ref] $signallingUri) -or
    $signallingUri.Scheme -ne "wss" -or
    $signallingUri.AbsolutePath -ne "/ws" -or
    -not [string]::IsNullOrEmpty($signallingUri.Query) -or
    -not [string]::IsNullOrEmpty($signallingUri.Fragment)) {
    throw "SignallingWebSocketUrl must be an absolute wss:// URL ending in /ws."
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run Register-Edge.ps1 from an elevated PowerShell session."
}
if ([string]::IsNullOrWhiteSpace($ConfigurationPath)) {
    $packageConfiguration = Join-Path $PSScriptRoot `
        "Coordinator\appsettings.Production.json"
    $ConfigurationPath = if (Test-Path -LiteralPath $packageConfiguration) {
        $packageConfiguration
    } else {
        Join-Path $PSScriptRoot `
            "..\publish\SaccadiaRemote.ServerService-win-x64\appsettings.Production.json"
    }
}
$ConfigurationPath = (Resolve-Path -LiteralPath $ConfigurationPath).Path
$configuration = Get-Content -LiteralPath $ConfigurationPath -Raw | ConvertFrom-Json
if ($null -eq $configuration.CoordinatorCluster) {
    $configuration | Add-Member -NotePropertyName CoordinatorCluster `
        -NotePropertyValue ([pscustomobject]@{ Enabled = $true; AllowedEdges = @() })
}

# Upsert by the administrator-visible NodeId. Pins and the WSS URL are replaced
# as one tuple so a partially updated trust binding can never reach the service.
$replacement = [pscustomobject]@{
    NodeId = $NodeId
    ClusterPublicKeyPin = $ClusterPublicKeyPin
    SignallingWebSocketUrl = $signallingUri.AbsoluteUri
    SignallingTlsPublicKeyPin = $SignallingTlsPublicKeyPin
}
$otherEdges = @($configuration.CoordinatorCluster.AllowedEdges | Where-Object {
    $_.NodeId -ne $NodeId
})
$configuration.CoordinatorCluster.AllowedEdges = @($otherEdges) + $replacement

$temporary = "$ConfigurationPath.new-$([Guid]::NewGuid().ToString('N'))"
$previous = "$ConfigurationPath.previous"
$configurationReplaced = $false
try {
    Set-Content -LiteralPath $temporary `
        -Value ($configuration | ConvertTo-Json -Depth 8) -Encoding UTF8
    $null = Get-Content -LiteralPath $temporary -Raw | ConvertFrom-Json
    $aclOutput = & icacls.exe $temporary /inheritance:r `
        /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" "*S-1-5-19:R" 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Could not secure the updated server configuration: $($aclOutput -join ' ')"
    }
    Copy-Item -LiteralPath $ConfigurationPath -Destination $previous -Force
    $previousAclOutput = & icacls.exe $previous /inheritance:r `
        /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" "*S-1-5-19:R" 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Could not secure the previous server configuration: $($previousAclOutput -join ' ')"
    }
    Move-Item -LiteralPath $temporary -Destination $ConfigurationPath -Force
    $configurationReplaced = $true

    Restart-Service -Name $ServiceName -Force
    (Get-Service -Name $ServiceName).WaitForStatus(
        "Running", [TimeSpan]::FromSeconds(20))
}
catch {
    # A stale backup from an older registration must never overwrite the
    # still-valid live configuration when preparation failed before Move-Item.
    if ($configurationReplaced -and (Test-Path -LiteralPath $previous)) {
        Copy-Item -LiteralPath $previous -Destination $ConfigurationPath -Force
        Restart-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    }
    throw
}
finally {
    Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
}

Write-Host "Coordinator now allows Edge '$NodeId'. The Edge may reconnect immediately."
