@echo off
setlocal
cd /d "%~dp0"

for %%I in ("%~dp0.") do set "SERVER_DIR=%%~fI"
for %%I in ("%~dp0..\SaccadiaRemote.ServerRelayService-win-x64") do set "SERVER_RELAY_DIR=%%~fI"
if not exist "%SERVER_RELAY_DIR%\SaccadiaRemote.ServerRelayService.exe" (
    echo Server relay was not found:
    echo %SERVER_RELAY_DIR%\SaccadiaRemote.ServerRelayService.exe
    echo Keep the server and server-relay publish folders next to each other.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SERVER_DIR%\Install-ServerNode.ps1" -ServerDirectory "%SERVER_DIR%" -ServerRelayDirectory "%SERVER_RELAY_DIR%"
if errorlevel 1 (
    echo Server node installation failed.
    pause
    exit /b 1
)
echo Server and server relay services are installed and running.
exit /b 0
