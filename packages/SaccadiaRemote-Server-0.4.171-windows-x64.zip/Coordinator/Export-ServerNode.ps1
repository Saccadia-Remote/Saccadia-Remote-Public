[CmdletBinding()]
param(
    [string] $PublishDirectory = "$PSScriptRoot\..\publish\SaccadiaRemote.ServerService-win-x64",
    [Parameter(Mandatory = $true)] [string] $OutputPath
)

$ErrorActionPreference = "Stop"
$PublishDirectory = (Resolve-Path -LiteralPath $PublishDirectory).Path
$serviceExe = Join-Path $PublishDirectory "SaccadiaRemote.ServerService.exe"
if (-not (Test-Path -LiteralPath $serviceExe)) {
    throw "Server service executable was not found: $serviceExe"
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run Export-ServerNode.ps1 from an elevated PowerShell session."
}

$dataRoot = Join-Path $env:ProgramData "SaccadiaRemote\Server"
if (-not (Test-Path -LiteralPath $dataRoot -PathType Container)) {
    throw "Persistent server state was not found: $dataRoot"
}
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
if (Test-Path -LiteralPath $OutputPath) {
    throw "Migration output already exists: $OutputPath"
}
$outputDirectory = Split-Path -Parent $OutputPath
New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null

function Read-MigrationPassword {
    $first = Read-Host "Migration bundle password" -AsSecureString
    $second = Read-Host "Repeat migration bundle password" -AsSecureString
    $firstPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($first)
    $secondPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($second)
    try {
        $firstText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($firstPointer)
        $secondText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secondPointer)
        if ($firstText -ne $secondText -or $firstText.Length -lt 12) {
            throw "Migration passwords must match and contain at least 12 characters."
        }
        return $firstText
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($firstPointer)
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secondPointer)
    }
}

$temporaryRoot = Join-Path ([IO.Path]::GetTempPath()) ("SaccadiaMigration-" + [Guid]::NewGuid().ToString("N"))
$archivePath = Join-Path $temporaryRoot "server.zip"
$stagingRoot = Join-Path $temporaryRoot "state"
$servicesToRestart = [Collections.Generic.List[string]]::new()
$password = Read-MigrationPassword
try {
    New-Item -ItemType Directory -Path $stagingRoot -Force | Out-Null
    foreach ($serviceName in @("SaccadiaRemoteServerService", "SaccadiaRemoteServerRelayService")) {
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($service -and $service.Status -ne "Stopped") {
            Stop-Service -Name $serviceName -Force
            $service.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
            $servicesToRestart.Add($serviceName)
        }
    }

    Copy-Item -LiteralPath $dataRoot -Destination (Join-Path $stagingRoot "Server") -Recurse
    $configurationPath = Join-Path $PublishDirectory "appsettings.Production.json"
    if (Test-Path -LiteralPath $configurationPath) {
        Copy-Item -LiteralPath $configurationPath -Destination $stagingRoot
    }
    Compress-Archive -Path (Join-Path $stagingRoot "*") -DestinationPath $archivePath
    $env:SACCADIA_MIGRATION_PASSWORD = $password
    & $serviceExe --encrypt-migration $archivePath $OutputPath
    if ($LASTEXITCODE -ne 0) {
        throw "Server migration encryption failed."
    }
    $aclOutput = & icacls.exe $OutputPath /inheritance:r `
        /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Could not protect migration output: $($aclOutput -join ' ')"
    }
} finally {
    Remove-Item Env:SACCADIA_MIGRATION_PASSWORD -ErrorAction SilentlyContinue
    $password = $null
    foreach ($serviceName in $servicesToRestart) {
        Start-Service -Name $serviceName
    }
    if (Test-Path -LiteralPath $temporaryRoot) {
        Remove-Item -LiteralPath $temporaryRoot -Recurse -Force
    }
}
Write-Host "Encrypted migration bundle created: $OutputPath"
Write-Host "It contains the domain TLS private key, cluster identity, configuration and database."
