[CmdletBinding()]
param(
    [string] $ServerDirectory = "",
    [string] $EdgeDirectory = "",
    [string] $CoordinatorHost = "",
    [string] $SignallingCertificatePath = "",
    [string] $SignallingCertificatePassword = "",
    [string] $ClusterCertificatePath = "",
    [string] $ClusterCertificatePassword = "",
    [string] $ManagementCertificatePath = "",
    [string] $ManagementCertificatePassword = "",
    [int] $BootstrapPort = 5000,
    [int] $ManagementPort = 5443,
    [int] $ClusterPort = 7000,
    [string] $EdgeNodeId = "edge-1",
    [int] $EdgeSignallingPort = 5100,
    [switch] $SkipLocalEdge,
    [switch] $AcceptDisclaimer,
    [switch] $ConfirmInstallation
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Assert-DisclaimerAcceptance.ps1")
. (Join-Path $PSScriptRoot "Installer-Preflight.ps1")
Assert-SaccadiaDisclaimerAcceptance -AcceptDisclaimer:$AcceptDisclaimer
$packageServer = Join-Path $PSScriptRoot "Coordinator"
$packageEdge = Join-Path $PSScriptRoot "Edge"
if ([string]::IsNullOrWhiteSpace($ServerDirectory)) {
    $ServerDirectory = if (Test-Path -LiteralPath `
            (Join-Path $packageServer "SaccadiaRemote.ServerService.exe")) {
        $packageServer
    } else {
        Join-Path $PSScriptRoot "..\publish\SaccadiaRemote.ServerService-win-x64"
    }
}
if ([string]::IsNullOrWhiteSpace($EdgeDirectory)) {
    $EdgeDirectory = if (Test-Path -LiteralPath `
            (Join-Path $packageEdge "SaccadiaRemote.EdgeService.exe")) {
        $packageEdge
    } else {
        Join-Path $PSScriptRoot "..\publish\SaccadiaRemote.EdgeService-win-x64"
    }
}
$ServerDirectory = (Resolve-Path -LiteralPath $ServerDirectory).Path
if (-not $SkipLocalEdge) {
    $EdgeDirectory = (Resolve-Path -LiteralPath $EdgeDirectory).Path
    if ([string]::IsNullOrWhiteSpace($CoordinatorHost)) {
        throw "CoordinatorHost is required when installing the bundled local Edge."
    }
}

if ([string]::IsNullOrWhiteSpace($CoordinatorHost)) {
    throw "CoordinatorHost is required for a public Server installation."
}
Assert-SaccadiaInstallationHost $CoordinatorHost "CoordinatorHost"
$tcpPorts = [ordered]@{
    "Coordinator bootstrap" = $BootstrapPort
    "Management console" = $ManagementPort
    "Coordinator cluster" = $ClusterPort
}
if (-not $SkipLocalEdge) {
    $tcpPorts["Local Edge signalling"] = $EdgeSignallingPort
}
Assert-SaccadiaInstallationPorts $tcpPorts
Assert-SaccadiaInstallationPfx $SignallingCertificatePath `
    $SignallingCertificatePassword "Coordinator signalling"
Assert-SaccadiaInstallationPfx $ClusterCertificatePath `
    $ClusterCertificatePassword "Coordinator cluster"
Assert-SaccadiaInstallationPfx $ManagementCertificatePath `
    $ManagementCertificatePassword "Management console"
Test-SaccadiaInstallationDns $CoordinatorHost "Coordinator"

$localEdgeText = if ($SkipLocalEdge) { "not installed" } else {
    "$EdgeNodeId at wss://${CoordinatorHost}:$EdgeSignallingPort/ws"
}
$roleText = if ($SkipLocalEdge) { "Coordinator" } else { "Coordinator + local Edge" }
$plan = @(
    "Role: $roleText",
    "Public host: $CoordinatorHost",
    "Bootstrap: TCP/UDP $BootstrapPort",
    "Management: TCP $ManagementPort",
    "Cluster mTLS: TCP $ClusterPort",
    "Local Edge: $localEdgeText",
    "Coordinator signalling certificate: $(Get-SaccadiaCertificatePlanText $SignallingCertificatePath 'installation-generated or existing identity')",
    "Coordinator cluster certificate: $(Get-SaccadiaCertificatePlanText $ClusterCertificatePath 'installation-generated or existing identity')",
    "Management certificate: $(Get-SaccadiaCertificatePlanText $ManagementCertificatePath 'Coordinator signalling certificate fallback')",
    "Persistent state: $env:ProgramData\SaccadiaRemote"
)
Confirm-SaccadiaInstallationPlan "Saccadia Remote Windows Server installation plan" `
    $plan -ConfirmInstallation:$ConfirmInstallation

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`"",
        "-ServerDirectory", "`"$ServerDirectory`"",
        "-EdgeDirectory", "`"$EdgeDirectory`""
    )
    foreach ($entry in @(
        @{ Name = "CoordinatorHost"; Value = $CoordinatorHost },
        @{ Name = "SignallingCertificatePath"; Value = $SignallingCertificatePath },
        @{ Name = "SignallingCertificatePassword"; Value = $SignallingCertificatePassword },
        @{ Name = "ClusterCertificatePath"; Value = $ClusterCertificatePath },
        @{ Name = "ClusterCertificatePassword"; Value = $ClusterCertificatePassword },
        @{ Name = "ManagementCertificatePath"; Value = $ManagementCertificatePath },
        @{ Name = "ManagementCertificatePassword"; Value = $ManagementCertificatePassword },
        @{ Name = "BootstrapPort"; Value = $BootstrapPort },
        @{ Name = "ManagementPort"; Value = $ManagementPort },
        @{ Name = "ClusterPort"; Value = $ClusterPort },
        @{ Name = "EdgeNodeId"; Value = $EdgeNodeId },
        @{ Name = "EdgeSignallingPort"; Value = $EdgeSignallingPort })) {
        if (-not [string]::IsNullOrWhiteSpace($entry.Value)) {
            $arguments += "-$($entry.Name)"
            $arguments += "`"$($entry.Value)`""
        }
    }
    if ($SkipLocalEdge) {
        $arguments += "-SkipLocalEdge"
    }
    $arguments += "-AcceptDisclaimer"
    $arguments += "-ConfirmInstallation"
    $elevated = Start-Process `
        -FilePath "powershell.exe" `
        -Verb RunAs `
        -Wait `
        -PassThru `
        -ArgumentList $arguments
    exit $elevated.ExitCode
}

& "$PSScriptRoot\Install-ServerService.ps1" `
    -PublishDirectory $ServerDirectory `
    -CoordinatorHost $CoordinatorHost `
    -SignallingCertificatePath $SignallingCertificatePath `
    -SignallingCertificatePassword $SignallingCertificatePassword `
    -ClusterCertificatePath $ClusterCertificatePath `
    -ClusterCertificatePassword $ClusterCertificatePassword `
    -ManagementCertificatePath $ManagementCertificatePath `
    -ManagementCertificatePassword $ManagementCertificatePassword `
    -BootstrapPort $BootstrapPort `
    -ManagementPort $ManagementPort `
    -ClusterPort $ClusterPort `
    -AcceptDisclaimer `
    -ConfirmInstallation

if (-not $SkipLocalEdge) {
    function Get-LocalStatusJson {
        param([string] $Url, [string] $Label)

        for ($attempt = 1; $attempt -le 30; $attempt++) {
            $payload = & curl.exe -ksS --max-time 2 $Url 2>$null
            if ($LASTEXITCODE -eq 0 -and $payload) {
                try { return ($payload | ConvertFrom-Json) } catch { }
            }
            Start-Sleep -Seconds 1
        }
        throw "$Label did not expose a valid local status response within 30 seconds."
    }

    function Get-LocalCoordinatorStatus {
        $serverExecutable = Join-Path $ServerDirectory "SaccadiaRemote.ServerService.exe"
        for ($attempt = 1; $attempt -le 30; $attempt++) {
            $lines = & $serverExecutable status 2>$null
            if ($LASTEXITCODE -eq 0 -and $lines) {
                $status = @{}
                foreach ($line in $lines) {
                    $separator = $line.IndexOf(": ", [StringComparison]::Ordinal)
                    if ($separator -gt 0) {
                        $status[$line.Substring(0, $separator)] =
                            $line.Substring($separator + 2)
                    }
                }
                if ($status["status"] -eq "running") {
                    return $status
                }
            }
            Start-Sleep -Seconds 1
        }
        throw "Coordinator did not expose local administrator status within 30 seconds."
    }

    $coordinatorStatus = Get-LocalCoordinatorStatus
    $clusterPin = [string] $coordinatorStatus["clusterPublicKeyPin"]
    if ($clusterPin -notmatch '^[0-9A-Fa-f]{64}$') {
        throw "Coordinator status did not provide a valid cluster pin."
    }

    $edgeUrl = "wss://${CoordinatorHost}:$EdgeSignallingPort/ws"
    # The bundled Edge is on the same machine. Loopback avoids depending on
    # public DNS reflection/hairpin NAT while the pinned cluster key still
    # authenticates the Coordinator endpoint cryptographically.
    & "$PSScriptRoot\Install-EdgeService.ps1" `
        -PublishDirectory $EdgeDirectory `
        -NodeId $EdgeNodeId `
        -SignallingWebSocketUrl $edgeUrl `
        -CoordinatorAddress "https://127.0.0.1:$ClusterPort" `
        -CoordinatorClusterPublicKeyPin $clusterPin `
        -SignallingPort $EdgeSignallingPort `
        -AcceptDisclaimer `
        -ConfirmInstallation

    $edgeStatus = Get-LocalStatusJson `
        "https://127.0.0.1:$EdgeSignallingPort/api/status" "Edge"
    & "$PSScriptRoot\Register-ServerEdge.ps1" `
        -ConfigurationPath (Join-Path $ServerDirectory "appsettings.Production.json") `
        -NodeId ([string] $edgeStatus.nodeId) `
        -ClusterPublicKeyPin ([string] $edgeStatus.clusterPublicKeyPin) `
        -SignallingWebSocketUrl ([string] $edgeStatus.signallingWebSocketUrl) `
        -SignallingTlsPublicKeyPin ([string] $edgeStatus.signallingTlsPublicKeyPin)

    for ($attempt = 1; $attempt -le 45; $attempt++) {
        $status = Get-LocalCoordinatorStatus
        if ([int] $status["edges.connected"] -ge 1 -and
            $status["clientAdmission.state"] -eq "ready") {
            break
        }
        if ($attempt -eq 45) {
            throw "The bundled Windows full node did not become ready within 45 seconds."
        }
        Start-Sleep -Seconds 1
    }
}
Write-Host "Saccadia Remote server node is installed and running."
