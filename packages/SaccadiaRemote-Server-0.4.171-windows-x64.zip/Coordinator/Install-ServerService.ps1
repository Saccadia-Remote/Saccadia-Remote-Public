[CmdletBinding()]
param(
    [string] $PublishDirectory = "$PSScriptRoot\..\publish\SaccadiaRemote.ServerService-win-x64",
    [string] $CoordinatorHost = "",
    [string] $SignallingCertificatePath = "",
    [string] $SignallingCertificatePassword = "",
    [string] $ClusterCertificatePath = "",
    [string] $ClusterCertificatePassword = "",
    [string] $ManagementCertificatePath = "",
    [string] $ManagementCertificatePassword = "",
    [int] $BootstrapPort = 5000,
    [int] $ManagementPort = 5443,
    [int] $ClusterPort = 7000,
    [switch] $AcceptDisclaimer,
    [switch] $ConfirmInstallation
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Assert-DisclaimerAcceptance.ps1")
. (Join-Path $PSScriptRoot "Installer-Preflight.ps1")
Assert-SaccadiaDisclaimerAcceptance -AcceptDisclaimer:$AcceptDisclaimer
$PublishDirectory = (Resolve-Path -LiteralPath $PublishDirectory).Path
$serviceName = "SaccadiaRemoteServerService"
$firewallRule = "Saccadia Remote Server Service"
$firewallUdpRule = "Saccadia Remote Server UDP Rendezvous"
$serviceExe = Join-Path $PublishDirectory "SaccadiaRemote.ServerService.exe"
if (-not [string]::IsNullOrWhiteSpace($CoordinatorHost)) {
    Assert-SaccadiaInstallationHost $CoordinatorHost "CoordinatorHost"
    Test-SaccadiaInstallationDns $CoordinatorHost "Coordinator"
}
Assert-SaccadiaInstallationPorts ([ordered]@{
    "Coordinator bootstrap" = $BootstrapPort
    "Management console" = $ManagementPort
    "Coordinator cluster" = $ClusterPort
})
Assert-SaccadiaInstallationPfx $SignallingCertificatePath `
    $SignallingCertificatePassword "Coordinator signalling"
Assert-SaccadiaInstallationPfx $ClusterCertificatePath `
    $ClusterCertificatePassword "Coordinator cluster"
Assert-SaccadiaInstallationPfx $ManagementCertificatePath `
    $ManagementCertificatePassword "Management console"
Confirm-SaccadiaInstallationPlan "Saccadia Remote Windows Coordinator installation plan" `
    @(
        "Role: Coordinator",
        "Public host: $(if ($CoordinatorHost) { $CoordinatorHost } else { 'existing configuration' })",
        "Bootstrap: TCP/UDP $BootstrapPort",
        "Management: TCP $ManagementPort",
        "Cluster mTLS: TCP $ClusterPort",
        "Executable: $serviceExe"
    ) -ConfirmInstallation:$ConfirmInstallation

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`"",
        "-PublishDirectory", "`"$PublishDirectory`""
    )
    foreach ($entry in @(
        @{ Name = "CoordinatorHost"; Value = $CoordinatorHost },
        @{ Name = "SignallingCertificatePath"; Value = $SignallingCertificatePath },
        @{ Name = "SignallingCertificatePassword"; Value = $SignallingCertificatePassword },
        @{ Name = "ClusterCertificatePath"; Value = $ClusterCertificatePath },
        @{ Name = "ClusterCertificatePassword"; Value = $ClusterCertificatePassword },
        @{ Name = "ManagementCertificatePath"; Value = $ManagementCertificatePath },
        @{ Name = "ManagementCertificatePassword"; Value = $ManagementCertificatePassword },
        @{ Name = "BootstrapPort"; Value = $BootstrapPort },
        @{ Name = "ManagementPort"; Value = $ManagementPort },
        @{ Name = "ClusterPort"; Value = $ClusterPort })) {
        if (-not [string]::IsNullOrWhiteSpace($entry.Value)) {
            $arguments += "-$($entry.Name)"
            $arguments += "`"$($entry.Value)`""
        }
    }
    $arguments += "-AcceptDisclaimer"
    $arguments += "-ConfirmInstallation"
    $elevated = Start-Process -FilePath "powershell.exe" -Verb RunAs -Wait `
        -PassThru -ArgumentList $arguments
    exit $elevated.ExitCode
}

if (-not (Test-Path -LiteralPath $serviceExe)) {
    throw "Server service executable was not found: $serviceExe"
}

$dataRoot = Join-Path $env:ProgramData "SaccadiaRemote\Server"
New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
$secretsRoot = Join-Path $dataRoot "secrets"
New-Item -ItemType Directory -Path $secretsRoot -Force | Out-Null
$configurationPath = Join-Path $PublishDirectory "appsettings.Production.json"
$existingConfiguration = if (Test-Path -LiteralPath $configurationPath) {
    Get-Content -Raw -LiteralPath $configurationPath | ConvertFrom-Json
} else {
    $null
}
function Assert-UsablePfx {
    param([string] $Path, [string] $Password, [string] $Role)
    $certificate = [Security.Cryptography.X509Certificates.X509Certificate2]::new(
        $Path,
        $Password,
        [Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    try {
        if (-not $certificate.HasPrivateKey) {
            throw "$Role PFX has no private key."
        }
        if ($certificate.NotAfter.ToUniversalTime() -le [DateTime]::UtcNow) {
            throw "$Role PFX is expired."
        }
    } finally {
        $certificate.Dispose()
    }
}
function Get-PfxPublicKeyHash {
    param([string] $Path, [string] $Password)
    $certificate = [Security.Cryptography.X509Certificates.X509Certificate2]::new(
        $Path,
        $Password,
        [Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString(
            $sha256.ComputeHash($certificate.GetPublicKey())).Replace("-", "")
    } finally {
        $sha256.Dispose()
        $certificate.Dispose()
    }
}
function Get-EstablishedPfxPassword {
    param([string] $Target, [string] $ConfiguredPassword)
    $sidecar = "$Target.password"
    if (Test-Path -LiteralPath $sidecar) {
        return (Get-Content -Raw -LiteralPath $sidecar).Trim()
    }
    return $ConfiguredPassword
}
function Install-PfxIdentity {
    param(
        [string] $Source,
        [string] $Target,
        [string] $Role,
        [string] $SourcePassword,
        [string] $TargetPassword)
    if (Test-Path -LiteralPath $Target) {
        $sourceHash = Get-PfxPublicKeyHash $Source $SourcePassword
        $targetHash = Get-PfxPublicKeyHash $Target $TargetPassword
        if ($sourceHash -ne $targetHash) {
            throw "Refusing to replace the established $Role key. Restore/import the intended identity or use the explicit certificate-rotation procedure."
        }
    }
    $temporary = "$Target.new-$([Guid]::NewGuid().ToString('N'))"
    try {
        Copy-Item -LiteralPath $Source -Destination $temporary
        Move-Item -LiteralPath $temporary -Destination $Target -Force
    } finally {
        if (Test-Path -LiteralPath $temporary) {
            Remove-Item -LiteralPath $temporary -Force
        }
    }
}
$signallingTarget = Join-Path $secretsRoot "server-public.pfx"
$clusterStorageTarget = Join-Path $secretsRoot "coordinator-cluster.pfx"
$clusterTarget = ""
if (-not [string]::IsNullOrWhiteSpace($SignallingCertificatePath)) {
    $SignallingCertificatePath = (Resolve-Path -LiteralPath $SignallingCertificatePath).Path
    Assert-UsablePfx $SignallingCertificatePath $SignallingCertificatePassword `
        "CoordinatorSignallingTLS"
    $oldSignallingPassword = Get-EstablishedPfxPassword $signallingTarget `
        ([string]$existingConfiguration.CoordinatorSignallingTLS.CertificatePassword)
    Install-PfxIdentity $SignallingCertificatePath $signallingTarget `
        "CoordinatorSignallingTLS" $SignallingCertificatePassword $oldSignallingPassword
    Set-Content -LiteralPath "$signallingTarget.password" `
        -Value $SignallingCertificatePassword `
        -Encoding UTF8 -NoNewline
}
if (-not [string]::IsNullOrWhiteSpace($ClusterCertificatePath)) {
    $ClusterCertificatePath = (Resolve-Path -LiteralPath $ClusterCertificatePath).Path
    Assert-UsablePfx $ClusterCertificatePath $ClusterCertificatePassword "Coordinator cluster"
    $clusterTarget = $clusterStorageTarget
    $oldClusterPassword = Get-EstablishedPfxPassword $clusterTarget `
        ([string]$existingConfiguration.CoordinatorClusterTLS.CertificatePassword)
    Install-PfxIdentity $ClusterCertificatePath $clusterTarget "Coordinator cluster" `
        $ClusterCertificatePassword $oldClusterPassword
    Set-Content -LiteralPath "$clusterTarget.password" -Value $ClusterCertificatePassword `
        -Encoding UTF8 -NoNewline
}
$managementTarget = ""
if (-not [string]::IsNullOrWhiteSpace($ManagementCertificatePath)) {
    $ManagementCertificatePath = (Resolve-Path -LiteralPath $ManagementCertificatePath).Path
    Assert-UsablePfx $ManagementCertificatePath $ManagementCertificatePassword `
        "CoordinatorManagementConsole"
    $managementTarget = Join-Path $secretsRoot "coordinator-management.pfx"
    $oldManagementPassword = Get-EstablishedPfxPassword $managementTarget `
        ([string]$existingConfiguration.CoordinatorManagementConsole.CertificatePassword)
    Install-PfxIdentity $ManagementCertificatePath $managementTarget `
        "CoordinatorManagementConsole" $ManagementCertificatePassword `
        $oldManagementPassword
    Set-Content -LiteralPath "$managementTarget.password" `
        -Value $ManagementCertificatePassword -Encoding UTF8 -NoNewline
}
$bundledTemplates = Join-Path $PublishDirectory "client-templates"
if (Test-Path -LiteralPath $bundledTemplates -PathType Container) {
    $templateTarget = Join-Path $dataRoot "client-templates"
    New-Item -ItemType Directory -Path $templateTarget -Force | Out-Null
    Copy-Item -Path (Join-Path $bundledTemplates "*") `
        -Destination $templateTarget -Recurse -Force -ErrorAction Stop
}
$aclOutput = & icacls.exe $dataRoot /inheritance:r `
    /grant:r "*S-1-5-18:(OI)(CI)F" `
    "*S-1-5-32-544:(OI)(CI)F" `
    "*S-1-5-19:(OI)(CI)M" 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "Could not secure the server data directory ${dataRoot}: $($aclOutput -join ' ')"
}

$writeConfiguration = -not (Test-Path -LiteralPath $configurationPath) -or
    -not [string]::IsNullOrWhiteSpace($CoordinatorHost) -or
    -not [string]::IsNullOrWhiteSpace($SignallingCertificatePath) -or
    -not [string]::IsNullOrWhiteSpace($ClusterCertificatePath) -or
    -not [string]::IsNullOrWhiteSpace($ManagementCertificatePath)
if ($writeConfiguration) {
    $configuration = @{
        Storage = @{ RootDirectory = $dataRoot }
        CoordinatorBootstrap = @{
            ListenPort = $BootstrapPort
            ClientUrl = $(if ($CoordinatorHost) {
                "https://${CoordinatorHost}:$BootstrapPort"
            } else { "" })
        }
        CoordinatorSignallingTLS = @{
            CertificatePath = $(if ($SignallingCertificatePath) {
                $signallingTarget
            } else { "" })
            CertificatePassword = $SignallingCertificatePassword
            CertificateSource = $(if ($SignallingCertificatePath) {
                "operator"
            } else { "installation-generated" })
        }
        CoordinatorManagementConsole = @{
            ListenPort = $ManagementPort
            BrowserUrl = $(if ($CoordinatorHost) {
                "https://${CoordinatorHost}:$ManagementPort"
            } else { "" })
            CertificatePath = $managementTarget
            CertificatePassword = $ManagementCertificatePassword
            CertificateSource = $(if ($managementTarget) { "operator" } else { "" })
        }
        CoordinatorDownloadService = @{
            Enabled = $true
            InternalPort = 5082
            ExecutablePath = ""
            BandwidthLimitMbps = 100
            PerDownloadLimitMbps = 20
            MaximumActiveDownloads = 100
            MaximumQueuedDownloads = 100000
            TicketLifetimeSec = 1800
            StartLeaseSec = 60
            StallTimeoutSec = 60
            MaximumTransferSec = 1800
            TokenBucketBurstMiB = 2
        }
        CoordinatorClusterTLS = @{
            ListenPort = $ClusterPort
            CertificatePath = $clusterTarget
            CertificatePassword = $ClusterCertificatePassword
            CertificateSource = $(if ($clusterTarget) { "operator" } else { "installation-generated" })
        }
    }
    # Keep unrelated production overrides (notably CoordinatorCluster AllowedEdges)
    # when an operator changes only a listener or certificate. Reinstalling a
    # service must not silently erase cluster membership.
    if ($null -ne $existingConfiguration) {
        foreach ($property in $existingConfiguration.PSObject.Properties) {
            if (-not $configuration.ContainsKey($property.Name)) {
                $configuration[$property.Name] = $property.Value
            }
        }
    }
    Set-Content -LiteralPath $configurationPath `
        -Value ($configuration | ConvertTo-Json -Depth 5) -Encoding UTF8
    $configAclOutput = & icacls.exe $configurationPath /inheritance:r `
        /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" "*S-1-5-19:R" 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Could not secure server configuration: $($configAclOutput -join ' ')"
    }
}

$existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($existing) {
    if ($existing.Status -ne [ServiceProcess.ServiceControllerStatus]::Stopped) {
        Stop-Service -Name $serviceName -Force
        (Get-Service -Name $serviceName).WaitForStatus("Stopped", [TimeSpan]::FromSeconds(20))
    }
    & sc.exe config $serviceName binPath= "`"$serviceExe`"" start= auto `
        obj= "NT AUTHORITY\LocalService" | Out-Null
} else {
    & sc.exe create $serviceName binPath= "`"$serviceExe`"" start= auto `
        obj= "NT AUTHORITY\LocalService" DisplayName= "Saccadia Remote Server" | Out-Null
}
if ($LASTEXITCODE -ne 0) {
    throw "Windows Service Control Manager rejected the server service configuration."
}

& sc.exe description $serviceName `
    "Hosts Saccadia Remote signalling, server identity, status pages, and client downloads." | Out-Null
& sc.exe failure $serviceName reset= 86400 `
    actions= restart/5000/restart/15000/restart/30000 | Out-Null
& sc.exe failureflag $serviceName 1 | Out-Null

Get-NetFirewallRule -DisplayName $firewallRule -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule
Get-NetFirewallRule -DisplayName $firewallUdpRule -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule
New-NetFirewallRule -DisplayName $firewallRule -Direction Inbound -Action Allow `
    -Protocol TCP -Program $serviceExe -Profile Any | Out-Null
New-NetFirewallRule -DisplayName $firewallUdpRule -Direction Inbound -Action Allow `
    -Protocol UDP -Program $serviceExe -Profile Any | Out-Null

Start-Service -Name $serviceName
(Get-Service -Name $serviceName).WaitForStatus("Running", [TimeSpan]::FromSeconds(20))

$renewalConfigurationPath = Join-Path $dataRoot "certificate-renewal.json"
$generatedSecretsRoot = Join-Path $dataRoot "data\secrets"
$signallingRenewalTarget = if ($SignallingCertificatePath) {
    $signallingTarget
} else {
    Join-Path $generatedSecretsRoot "server-public.pfx"
}
$clusterRenewalTarget = if ($ClusterCertificatePath) {
    $clusterStorageTarget
} else {
    Join-Path $generatedSecretsRoot "coordinator-cluster.pfx"
}
$renewalConfiguration = @{
    Version = 1
    RenewBeforeDays = 180
    Certificates = @(
        @{
            Role = "CoordinatorSignallingTLS"
            CertificatePath = $signallingRenewalTarget
            PasswordFile = "$signallingRenewalTarget.password"
            ManifestPath = Join-Path $dataRoot `
                "data\identity\coordinator-public-certificate.json"
            Source = $(if ($SignallingCertificatePath) {
                "operator"
            } else { "installation-generated" })
            RestartGroup = "server"
        },
        @{
            Role = "CoordinatorClusterTLS"
            CertificatePath = $clusterRenewalTarget
            PasswordFile = "$clusterRenewalTarget.password"
            ManifestPath = Join-Path $dataRoot `
                "data\identity\coordinator-cluster-certificate.json"
            Source = $(if ($ClusterCertificatePath) {
                "operator"
            } else { "installation-generated" })
            RestartGroup = "server"
        }
    )
}
Set-Content -LiteralPath $renewalConfigurationPath `
    -Value ($renewalConfiguration | ConvertTo-Json -Depth 5) -Encoding UTF8
$renewalAcl = & icacls.exe $renewalConfigurationPath /inheritance:r `
    /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "Could not secure certificate renewal configuration: $($renewalAcl -join ' ')"
}
$renewalTool = Join-Path $PublishDirectory "tools\certificates\saccadia-cert.exe"
$renewalScript = Join-Path $PublishDirectory "Invoke-CertificateRenewal.ps1"
if ((Test-Path -LiteralPath $renewalTool) -and
    (Test-Path -LiteralPath $renewalScript)) {
    $taskArguments = "-NoProfile -ExecutionPolicy Bypass -File `"$renewalScript`" " +
        "-ToolPath `"$renewalTool`" -ConfigurationPath `"$renewalConfigurationPath`" " +
        "-ServiceName `"$serviceName`""
    $action = New-ScheduledTaskAction -Execute "powershell.exe" `
        -Argument $taskArguments
    $trigger = New-ScheduledTaskTrigger -Daily -At "03:00" `
        -RandomDelay (New-TimeSpan -Hours 6)
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable
    Register-ScheduledTask -TaskName "SaccadiaRemoteCertificateRenewal" `
        -Action $action -Trigger $trigger -Settings $settings -User "SYSTEM" `
        -RunLevel Highest -Force | Out-Null
}
Write-Host "Saccadia Remote ServerService is installed and running."
