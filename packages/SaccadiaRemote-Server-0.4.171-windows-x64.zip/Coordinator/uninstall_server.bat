@echo off
setlocal
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-ServerNode.ps1"
if errorlevel 1 (
    echo Server node removal failed.
    pause
    exit /b 1
)
echo Server and server relay services were removed.
exit /b 0
