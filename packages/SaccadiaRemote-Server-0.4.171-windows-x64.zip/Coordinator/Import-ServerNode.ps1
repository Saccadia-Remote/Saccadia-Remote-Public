[CmdletBinding()]
param(
    [string] $PublishDirectory = "$PSScriptRoot\..\publish\SaccadiaRemote.ServerService-win-x64",
    [Parameter(Mandatory = $true)] [string] $BundlePath
)

$ErrorActionPreference = "Stop"
$PublishDirectory = (Resolve-Path -LiteralPath $PublishDirectory).Path
$BundlePath = (Resolve-Path -LiteralPath $BundlePath).Path
$serviceExe = Join-Path $PublishDirectory "SaccadiaRemote.ServerService.exe"
if (-not (Test-Path -LiteralPath $serviceExe)) {
    throw "Server service executable was not found: $serviceExe"
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run Import-ServerNode.ps1 from an elevated PowerShell session."
}

$dataRoot = Join-Path $env:ProgramData "SaccadiaRemote\Server"
if ((Test-Path -LiteralPath $dataRoot) -and
    (Get-ChildItem -LiteralPath $dataRoot -Force | Select-Object -First 1)) {
    throw "Refusing to overwrite existing server state: $dataRoot"
}
$securePassword = Read-Host "Migration bundle password" -AsSecureString
$passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
$password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
$temporaryRoot = Join-Path ([IO.Path]::GetTempPath()) ("SaccadiaMigration-" + [Guid]::NewGuid().ToString("N"))
$archivePath = Join-Path $temporaryRoot "server.zip"
$expandedRoot = Join-Path $temporaryRoot "state"
$servicesToRestart = [Collections.Generic.List[string]]::new()
try {
    New-Item -ItemType Directory -Path $expandedRoot -Force | Out-Null
    $env:SACCADIA_MIGRATION_PASSWORD = $password
    & $serviceExe --decrypt-migration $BundlePath $archivePath
    if ($LASTEXITCODE -ne 0) {
        throw "Migration bundle authentication failed."
    }
    Expand-Archive -LiteralPath $archivePath -DestinationPath $expandedRoot
    $restoredData = Join-Path $expandedRoot "Server"
    if (-not (Test-Path -LiteralPath $restoredData -PathType Container)) {
        throw "Migration bundle does not contain persistent server state."
    }

    foreach ($serviceName in @("SaccadiaRemoteServerService", "SaccadiaRemoteServerRelayService")) {
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($service -and $service.Status -ne "Stopped") {
            Stop-Service -Name $serviceName -Force
            $service.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
            $servicesToRestart.Add($serviceName)
        }
    }
    if (Test-Path -LiteralPath $dataRoot) {
        Remove-Item -LiteralPath $dataRoot
    }
    Move-Item -LiteralPath $restoredData -Destination $dataRoot
    $restoredConfiguration = Join-Path $expandedRoot "appsettings.Production.json"
    if (Test-Path -LiteralPath $restoredConfiguration) {
        Copy-Item -LiteralPath $restoredConfiguration -Destination $PublishDirectory -Force
    }
    $aclOutput = & icacls.exe $dataRoot /inheritance:r `
        /grant:r "*S-1-5-18:(OI)(CI)F" `
        "*S-1-5-32-544:(OI)(CI)F" `
        "*S-1-5-19:(OI)(CI)M" 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Could not secure restored server data: $($aclOutput -join ' ')"
    }
} finally {
    Remove-Item Env:SACCADIA_MIGRATION_PASSWORD -ErrorAction SilentlyContinue
    $password = $null
    foreach ($serviceName in $servicesToRestart) {
        Start-Service -Name $serviceName
    }
    if (Test-Path -LiteralPath $temporaryRoot) {
        Remove-Item -LiteralPath $temporaryRoot -Recurse -Force
    }
}
Write-Host "Server identity and persistent state were imported."
Write-Host "Keep the same public domain and update its DNS record to this host before starting clients."
