[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`""
    )
    $elevated = Start-Process `
        -FilePath "powershell.exe" `
        -Verb RunAs `
        -Wait `
        -PassThru `
        -ArgumentList $arguments
    exit $elevated.ExitCode
}

if (Get-Service -Name "SaccadiaRemoteEdgeService" -ErrorAction SilentlyContinue) {
    & "$PSScriptRoot\Uninstall-EdgeService.ps1"
}
& "$PSScriptRoot\Uninstall-ServerService.ps1"
& "$PSScriptRoot\Uninstall-ServerRelayService.ps1"
Write-Host "Saccadia Remote server node services were removed."
