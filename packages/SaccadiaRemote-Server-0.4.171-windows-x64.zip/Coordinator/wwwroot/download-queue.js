const parameters = new URLSearchParams(window.location.search);
const platform = parameters.get("platform") || "windows";
const architecture = parameters.get("architecture") || "x64";
const fileName = parameters.get("file") || "";
const title = document.getElementById("queue-title");
const message = document.getElementById("queue-message");
const positionPanel = document.getElementById("queue-position");
const positionText = document.getElementById("queue-number");
const estimate = document.getElementById("queue-estimate");
const progress = document.getElementById("queue-progress-bar");
const cancel = document.getElementById("queue-cancel");
let ticketId = "";
let stopped = false;
let cancelMode = "cancel";

function safeSegment(value) {
  return encodeURIComponent(value);
}

function delay(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

async function requestTicket() {
  const path = `/api/download-queue/clients/${safeSegment(platform)}/` +
    `${safeSegment(architecture)}/${safeSegment(fileName)}`;
  const response = await fetch(path, { method: "POST", cache: "no-store" });
  if (!response.ok) throw new Error(`The download service returned HTTP ${response.status}.`);
  return response.json();
}

async function readTicket(id) {
  const response = await fetch(`/api/download-queue/${safeSegment(id)}`, { cache: "no-store" });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`The download service returned HTTP ${response.status}.`);
  return response.json();
}

function showWaiting(state) {
  title.textContent = "Your download is in the queue";
  message.textContent = "This keeps downloads from slowing down remote-control connections.";
  positionPanel.hidden = false;
  positionText.textContent = state.position || 1;
  estimate.textContent = state.estimatedWaitSec > 0
    ? `Estimated wait: about ${Math.max(1, Math.ceil(state.estimatedWaitSec / 60))} min.`
    : "Your download will begin shortly.";
  // The exact queue length is intentionally not required by the protocol. A moving
  // indicator makes that clear without presenting a false percentage to the user.
  progress.style.width = `${20 + ((Date.now() / 250) % 60)}%`;
}

function startDownload(state) {
  stopped = true;
  positionPanel.hidden = true;
  progress.style.width = "100%";
  title.textContent = "Your download is starting";
  message.textContent = "You can leave this page after the browser starts saving the installer.";
  estimate.textContent = "If your browser asks for permission, choose Save.";
  cancel.textContent = "Back to downloads";
  cancelMode = "back";
  const link = document.createElement("a");
  link.href = state.downloadUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

async function run() {
  if (!fileName || !/^[-_.A-Za-z0-9]+(\.msi|\.tar\.gz|\.apk)$/i.test(fileName))
    throw new Error("The installer address is invalid.");

  let state = await requestTicket();
  ticketId = state.ticketId;
  while (!stopped) {
    if (state.state === "ready" && state.downloadUrl) {
      startDownload(state);
      return;
    }
    if (state.state !== "waiting")
      throw new Error(state.error || `The download is ${state.state}.`);
    showWaiting(state);
    await delay(Math.max(1, state.retryAfterSec || 2) * 1000);
    if (stopped) return;
    state = await readTicket(ticketId);
    if (!state) {
      message.textContent = "The download service restarted. Restoring your place...";
      state = await requestTicket();
      ticketId = state.ticketId;
    }
  }
}

cancel.addEventListener("click", async () => {
  if (cancelMode === "back") {
    window.location.href = "/downloads";
    return;
  }
  if (cancelMode === "retry") {
    window.location.reload();
    return;
  }
  stopped = true;
  if (ticketId) {
    try { await fetch(`/api/download-queue/${safeSegment(ticketId)}`, { method: "DELETE" }); }
    catch { /* Cancellation is best-effort when the server is restarting. */ }
  }
  window.location.href = "/downloads";
});

window.addEventListener("pagehide", () => {
  if (ticketId && !stopped) {
    fetch(`/api/download-queue/${safeSegment(ticketId)}`, {
      method: "DELETE",
      keepalive: true
    }).catch(() => {});
  }
});

run().catch((error) => {
  title.textContent = "Download temporarily unavailable";
  message.textContent = error.message || "Please try again in a moment.";
  positionPanel.hidden = true;
  estimate.textContent = "The remote-control service is unaffected.";
  cancel.textContent = "Try again";
  cancelMode = "retry";
});
