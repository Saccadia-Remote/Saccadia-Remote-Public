function text(id, value) {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
}

function duration(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return days > 0 ? `${days}d ${hours}h` : `${hours}h ${minutes}m`;
}

function bytes(value) {
  if (!Number.isFinite(value)) return "-";
  const units = ["B", "KiB", "MiB", "GiB"];
  let current = Math.max(0, value);
  let unit = 0;
  while (current >= 1024 && unit < units.length - 1) {
    current /= 1024;
    unit += 1;
  }
  return `${current.toFixed(unit > 1 ? 1 : 0)} ${units[unit]}`;
}

async function loadStatus() {
  const health = document.getElementById("health");
  try {
    // Overview is public and receives only an allowlisted aggregate snapshot. The detailed
    // status page keeps using the authenticated endpoint.
    const endpoint = document.body.dataset.page === "home" ? "/api/overview" : "/api/status";
    const response = await fetch(endpoint, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (health) { health.textContent = "Running"; health.className = "status"; }
    text("clients", data.clients);
    const online = data.online || {};
    text("client-freshness", `${online.fresh ?? 0} / ${online.stale ?? 0}`);
    const geo = data.geo || {};
    const geoDb = geo.databaseAvailable ? "DB ready" : "DB unavailable";
    text("geo-status", `${geoDb}; endpoints ${geo.endpointsWithGeo ?? 0}/${geo.onlineEndpoints ?? 0} geo, ` +
      `${geo.endpointsWithObservedSubnet ?? 0}/${geo.onlineEndpoints ?? 0} subnet; ` +
      `relays real/synthetic/missing ${geo.clientRelaysWithRealGeo ?? 0}/` +
      `${geo.clientRelaysWithSyntheticGeo ?? 0}/${geo.clientRelaysWithoutGeo ?? 0}`);
    const edges = data.edges || {};
    const edgeNodes = Array.isArray(edges.nodes) ? edges.nodes : [];
    text("edge-count", `${edges.connected ?? 0} / ${edges.allowed ?? 0}`);
    const admission = data.clientAdmission || {};
    const admissionDelay = (admission.warmupRemainingSeconds ?? 0) > 0
      ? `, warmup ${Math.ceil(admission.warmupRemainingSeconds)}s`
      : (admission.stabilizationRemainingSeconds ?? 0) > 0
        ? `, stabilizing ${Math.ceil(admission.stabilizationRemainingSeconds)}s`
        : "";
    text("client-admission", `${admission.state ?? "unknown"}: ` +
      `${admission.readyEdges ?? 0}/${admission.allowedEdges ?? 0} ready, ` +
      `${admission.connectedEdges ?? 0} connected${admissionDelay}`);
    text("edge-connections", edgeNodes.length === 0
      ? "No connected Edge nodes"
      : edgeNodes.map((edge) => {
          const metrics = edge.metrics || {};
          const credit = edge.livenessCredit || {};
          const state = edge.ready ? "ready" : "unavailable";
          return `${edge.nodeId}: ${metrics.onlineConnections ?? 0} sockets, ` +
            `liveness ${credit.availableTokens ?? 0}/${credit.windowSize ?? 0} ` +
            `(q:${credit.queuedProbes ?? 0}, f:${credit.inFlightProbes ?? 0}; ${state})`;
        }).join("\n"));
    const balance = data.edgeAssignments?.balance || {};
    const balanceEdges = Array.isArray(balance.edges) ? balance.edges : [];
    text("edge-assignment-balance", balanceEdges.length === 0
      ? `Waiting for first ${balance.quantumMilliseconds ?? 1000} ms quantum`
      : balanceEdges.map((edge) =>
          `${edge.nodeId}: ${edge.onlineAtQuantumStart ?? 0} base + ` +
          `${edge.distributed ?? 0} assigned = ${edge.projectedOnline ?? 0} projected`)
        .join("\n"));
    text("edge-resources", edgeNodes.length === 0
      ? "-"
      : edgeNodes.map((edge) => {
          const metrics = edge.metrics || {};
          const connectionLimit = (metrics.configuredMaximumConnections ?? 0) > 0
            ? metrics.configuredMaximumConnections
            : "unlimited";
          return `${edge.nodeId}: ${bytes(metrics.workingSetBytes)}, ` +
            `${connectionLimit} sockets`;
        }).join("\n"));
    text("sessions", data.sessions);
    const sessionPools = data.sessionPools || {};
    text("session-relay-refill", `${sessionPools.underfilled ?? 0} / ` +
      `${sessionPools.pendingRelayDeliveries ?? 0}`);
    text("relays", data.relays);
    const pool = data.relayPool || {};
    text("relay-pool", `${pool.warmVacant ?? 0} / ${pool.leased ?? 0} / ${pool.warming ?? 0}`);
    const warmups = data.relayWarmup || {};
    text("relay-warmups", `${warmups.warmupsReady ?? 0} / ` +
      `${warmups.warmupsFailed ?? 0} / ${warmups.pendingWarmups ?? 0}`);
    const liveness = data.liveness || {};
    text("liveness", `${liveness.queueDepth ?? 0} queued ` +
      `(${liveness.onDemandQueueDepth ?? 0} on-demand) / ` +
      `${liveness.nominalAggregateProbeRate ?? 0}/s nominal / ` +
      `${liveness.batchesSent ?? 0}:${liveness.reportsReceived ?? 0} batches:reports`);
    text("lease", `${Math.round(liveness.effectiveSweepSeconds ?? 0)}s / ${liveness.effectiveLeaseSeconds ?? 0}s`);
    const dispatch = data.clientMessageDispatch || {};
    text("message-dispatch", `${dispatch.activeRouteQueues ?? 0} routes / ` +
      `${dispatch.pendingMessages ?? 0} pending / ${dispatch.rejectedMessages ?? 0} rejected`);
    const identities = data.identityCache || {};
    text("identity-cache", `${identities.cacheEntries ?? 0} / ${identities.dirtyLastSeen ?? 0}`);
    const resources = data.resources || {};
    text("process-resources", `${(resources.cpuPercent ?? 0).toFixed(1)}% / ${bytes(resources.workingSetBytes)}`);
    text("gc-resources", `${bytes(resources.gcHeapBytes)} / ${bytes(resources.gcFragmentedBytes)}`);
    text("thread-pool", `${resources.availableWorkerThreads ?? 0} / ${resources.maximumWorkerThreads ?? 0} workers; ${resources.availableIoThreads ?? 0} / ${resources.maximumIoThreads ?? 0} I/O`);
    text("descriptor-headroom", resources.fileDescriptorHeadroom >= 0
      ? `${resources.fileDescriptorHeadroom} of ${resources.fileDescriptorSoftLimit}`
      : "Unavailable on this platform");
    const fdSlots = resources.estimatedAdditionalDescriptorSlots;
    text("estimated-slots",
      `${resources.estimatedAdditionalOnlineSlots ?? 0} effective; ` +
      `${resources.estimatedAdditionalMemorySlots ?? 0} memory; ` +
      `${fdSlots >= 0 ? fdSlots : "-"} FD (informational)`);
    const downloads = data.downloadGateway || {};
    const downloadQueue = downloads.queue || {};
    text("download-service", downloads.enabled
      ? `${downloads.status ?? "unknown"}; PID ${downloads.processId ?? "-"}; ` +
        `${downloads.restartCount ?? 0} restarts` +
        (downloads.lastFailure ? `; last failure: ${downloads.lastFailure}` : "")
      : "Disabled");
    text("download-queue", downloads.enabled
      ? `${downloadQueue.activeDownloads ?? 0} / ${downloadQueue.queuedDownloads ?? 0}; ` +
        `${downloadQueue.maximumActiveDownloads ?? 0} active / ` +
        `${downloadQueue.maximumQueuedDownloads ?? 0} queued limits`
      : "-");
    text("download-traffic", downloads.enabled
      ? `${bytes(downloadQueue.bytesSent ?? 0)} sent; ` +
        `${downloadQueue.completedDownloads ?? 0} completed / ` +
        `${downloadQueue.failedDownloads ?? 0} failed; ` +
        `${downloadQueue.bandwidthLimitMbps ?? 0} Mbit/s limit`
      : "-");
    text("completed-client-downloads-total", data.completedClientDownloadsTotal ?? 0);
    text("uptime", duration(data.uptimeSeconds));
    const certificates = data.certificates || {};
    text("signalling-certificate", certificateSummary(certificates.coordinatorSignallingTls));
    const management = certificates.coordinatorManagementConsole || {};
    text("management-certificate", management.source === "fallback"
      ? `fallback to ${management.uses}`
      : certificateSummary(management.certificate));
    text("cluster-certificate", certificateSummary(certificates.coordinatorClusterTls));
    text("public-key", data.coordinatorSignallingTlsPublicKeyPin || "-");
    text("signalling-public-key", data.coordinatorSignallingTlsPublicKeyPin || "-");
    text("cluster-public-key", data.clusterPublicKeyPin || "Disabled");
    text("protocol", data.securityProtocol);
    text("signalling-protocol", data.signallingProtocol);
    text("cluster-protocol", data.clusterProtocol ?? "Disabled");
    text("version", data.version);
    const serverRelays = data.serverRelays || [];
    const onlineServerRelays = serverRelays.filter((entry) => entry.runtime?.online).length;
    text("server-relay-state", `${onlineServerRelays} online / ${serverRelays.length} allowlisted`);
    await loadServerRelays();
    await loadServerRelayPackages();
  } catch (error) {
    if (health) { health.textContent = "Unavailable"; health.className = "status error"; }
  }
}

async function loadServerRelays() {
  const target = document.getElementById("server-relay-allow-list");
  if (!target) return;
  const response = await fetch("/api/status/server-relays", { cache: "no-store" });
  if (!response.ok) {
    target.innerHTML = `<tr><td colspan="6">Unavailable</td></tr>`;
    return;
  }
  const entries = await response.json();
  const expanded = expandedServerRelayFingerprints(target);
  target.replaceChildren();
  if (entries.length === 0) {
    target.appendChild(tableMessageRow("No server relays allowlisted"));
    return;
  }
  for (const entry of entries) {
    target.append(...serverRelayRows(entry, expanded));
  }
}

function expandedServerRelayFingerprints(target) {
  return new Set(Array.from(target.querySelectorAll(".server-relay-details:not([hidden])"))
    .map((row) => row.dataset.fingerprint)
    .filter(Boolean));
}

function serverRelayRows(entry, expanded) {
  const allow = entry.allowList || entry.allowlist || {};
  const runtime = entry.runtime || null;
  const fingerprint = allow.fingerprint || runtime?.fingerprint || "";
  const detailsId = `server-relay-details-${fingerprint}`;
  const initiallyExpanded = expanded?.has(fingerprint);
  const row = document.createElement("tr");
  row.className = runtime?.online ? "server-relay-online" : "server-relay-offline";

  const expand = document.createElement("button");
  expand.type = "button";
  expand.className = "icon-button";
  expand.textContent = initiallyExpanded ? "-" : "+";
  expand.setAttribute("aria-controls", detailsId);
  expand.setAttribute("aria-expanded", initiallyExpanded ? "true" : "false");
  expand.addEventListener("click", () => toggleServerRelayDetails(expand, detailsId));

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.textContent = allow.enabled ? "Disable" : "Enable";
  toggle.addEventListener("click", () => setServerRelayEnabled(entry, !allow.enabled));

  const edit = document.createElement("button");
  edit.type = "button";
  edit.textContent = "Edit";
  edit.addEventListener("click", () => openServerRelayEditDialog(entry));

  const remove = document.createElement("button");
  remove.type = "button";
  remove.textContent = "Delete";
  remove.className = "danger";
  remove.addEventListener("click", () => deleteServerRelay(fingerprint));

  row.append(
    tableCell(expand),
    tableCell(relayIdentitySummary(fingerprint, allow.note)),
    tableCell(`${allow.enabled ? "enabled" : "disabled"} / ${runtime?.online ? "online" : "offline"}`),
    tableCell(allow.addressPattern || "-"),
    tableCell(allow.lastObservedAddress || "-"),
    tableCell(toggle, edit, remove)
  );

  const details = document.createElement("tr");
  details.id = detailsId;
  details.dataset.fingerprint = fingerprint;
  details.className = "server-relay-details";
  details.hidden = !initiallyExpanded;
  const detailCell = document.createElement("td");
  detailCell.colSpan = 6;
  detailCell.appendChild(serverRelayDetails(allow, runtime));
  details.appendChild(detailCell);

  return [row, details];
}

function relayIdentitySummary(fingerprint, note) {
  const box = document.createElement("div");
  box.className = "relay-identity";
  const code = document.createElement("code");
  code.textContent = shortFingerprint(fingerprint);
  box.appendChild(code);
  if (note) {
    const noteElement = document.createElement("span");
    noteElement.className = "relay-note";
    noteElement.textContent = note;
    box.appendChild(noteElement);
  }
  return box;
}

function serverRelayDetails(allow, runtime) {
  const dl = document.createElement("dl");
  dl.className = "details-grid";
  addDetail(dl, "Fingerprint", allow.fingerprint || runtime?.fingerprint || "-");
  addDetail(dl, "Enabled", allow.enabled ? "true" : "false");
  addDetail(dl, "Online", runtime?.online ? "true" : "false");
  addDetail(dl, "Allowed source", allow.addressPattern || "-");
  addDetail(dl, "Observed source", allow.lastObservedAddress || "-");
  addDetail(dl, "Last accepted", formatDateTime(allow.lastAcceptedAtUtc));
  addDetail(dl, "Last reject", allow.lastRejectReason || "-");
  addDetail(dl, "Advertised relay", runtime ? `${runtime.address || "-"}:${runtime.port || 0}` : "-");
  addDetail(dl, "Transport", runtime?.transport || "-");
  addDetail(dl, "Traffic limit", runtime ? trafficLimitLabel(runtime.trafficLimitMbps) : "-");
  addDetail(dl, "Active pairs", runtime ? `${runtime.activePairs || 0}` : "-");
  addDetail(dl, "Warm state", runtime?.warmState || "-");
  addDetail(dl, "Connected", formatDateTime(runtime?.connectedAtUtc));
  addDetail(dl, "Last seen", formatDateTime(runtime?.lastSeenUtc));
  addDetail(dl, "Note", allow.note || "-");
  return dl;
}

function openServerRelayEditDialog(entry) {
  const allow = entry.allowList || entry.allowlist || {};
  const dialog = document.getElementById("server-relay-edit-dialog");
  const form = document.getElementById("server-relay-edit-form");
  if (!dialog || !form) return;
  form.dataset.fingerprint = allow.fingerprint || "";
  form.dataset.enabled = allow.enabled ? "true" : "false";
  form.elements.fingerprint.value = allow.fingerprint || "";
  form.elements.addressPattern.value = allow.addressPattern || "";
  form.elements.note.value = allow.note || "";
  if (typeof dialog.showModal === "function") dialog.showModal();
  else dialog.setAttribute("open", "");
  form.elements.addressPattern.focus();
}

function addDetail(parent, name, value) {
  const dt = document.createElement("dt");
  dt.textContent = name;
  const dd = document.createElement("dd");
  dd.textContent = value || "-";
  parent.append(dt, dd);
}

function toggleServerRelayDetails(button, detailsId) {
  const details = document.getElementById(detailsId);
  if (!details) return;
  details.hidden = !details.hidden;
  button.textContent = details.hidden ? "+" : "-";
  button.setAttribute("aria-expanded", details.hidden ? "false" : "true");
}

function closeServerRelayEditDialog() {
  const dialog = document.getElementById("server-relay-edit-dialog");
  if (!dialog) return;
  if (typeof dialog.close === "function") dialog.close();
  else dialog.removeAttribute("open");
}

async function submitServerRelayEdit(form) {
  const response = await fetch("/api/status/server-relays", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      fingerprint: form.elements.fingerprint.value,
      addressPattern: form.elements.addressPattern.value,
      enabled: form.dataset.enabled === "true",
      note: form.elements.note.value || null
    })
  });
  if (response.ok) {
    closeServerRelayEditDialog();
    await loadServerRelays();
  }
}

async function setServerRelayEnabled(entry, enabled) {
  const allow = entry.allowList || entry.allowlist || {};
  const response = await fetch("/api/status/server-relays", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      fingerprint: allow.fingerprint,
      addressPattern: allow.addressPattern,
      enabled,
      note: allow.note || null
    })
  });
  if (response.ok) await loadServerRelays();
}

async function deleteServerRelay(fingerprint) {
  if (!fingerprint) return;
  if (!confirm(`Delete server relay ${shortFingerprint(fingerprint)}?`)) return;
  const response = await fetch(`/api/status/server-relays/${encodeURIComponent(fingerprint)}`, {
    method: "DELETE"
  });
  if (response.ok || response.status === 404) await loadServerRelays();
}

function tableCell(...children) {
  const td = document.createElement("td");
  for (const child of children) {
    if (typeof child === "string") td.appendChild(document.createTextNode(child));
    else td.appendChild(child);
  }
  return td;
}

function tableMessageRow(message) {
  const row = document.createElement("tr");
  const cell = document.createElement("td");
  cell.colSpan = 6;
  cell.textContent = message;
  row.appendChild(cell);
  return row;
}

function shortFingerprint(value) {
  return value && value.length > 16 ? `${value.slice(0, 12)}...${value.slice(-8)}` : value || "-";
}

function formatDateTime(value) {
  return value ? new Date(value).toISOString().replace("T", " ").slice(0, 19) : "-";
}

function trafficLimitLabel(value) {
  const limit = Number(value || 0);
  return limit <= 0 ? "Unlimited" : `${limit} Mbit/s`;
}

async function loadServerRelayPackages() {
  await loadServerRelayPackage("windows", "x64", "server-relay-package-windows");
  await loadServerRelayPackage("linux", "x64", "server-relay-package-linux");
}

async function loadServerRelayPackage(platform, architecture, elementId) {
  const link = document.getElementById(elementId);
  if (!link || link.dataset.ready === "true") return;
  const response = await fetch(`/api/status/server-relay-packages/${platform}/${architecture}`, {
    cache: "no-store"
  });
  if (!response.ok) return;
  const packageInfo = await response.json();
  link.href = packageInfo.downloadUrl;
  link.classList.remove("disabled");
  link.removeAttribute("aria-disabled");
  link.dataset.ready = "true";
}

async function submitServerRelay(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const body = {
    fingerprint: form.elements.fingerprint.value,
    addressPattern: form.elements.addressPattern.value,
    enabled: true,
    note: form.elements.note.value || null
  };
  const response = await fetch("/api/status/server-relays", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (response.ok) {
    form.reset();
    await loadServerRelays();
  }
}

function certificateSummary(certificate) {
  if (!certificate) return "Disabled";
  const expires = certificate.notAfterUtc
    ? new Date(certificate.notAfterUtc).toISOString().slice(0, 10)
    : "unknown";
  const sans = (certificate.subjectAlternativeNames || []).join(", ") || "no SAN";
  return `${certificate.source || "unknown"}; expires ${expires}; ${sans}; ` +
    `migration export ${certificate.migrationExportable ? "ready" : "unavailable"}`;
}

async function copyValue(button) {
  const target = document.getElementById(button.dataset.copyTarget);
  const value = target?.textContent?.trim();
  if (!value || value === "-") return;

  const original = button.textContent;
  try {
    if (navigator.clipboard) await navigator.clipboard.writeText(value);
    else if (!copyLegacy(value)) throw new Error("Clipboard API is unavailable.");
    button.textContent = "Copied";
  } catch {
    button.textContent = copyLegacy(value) ? "Copied" : "Unavailable";
  }
  window.setTimeout(() => { button.textContent = original; }, 1400);
}

function copyLegacy(value) {
  const input = document.createElement("textarea");
  input.value = value;
  input.setAttribute("readonly", "");
  input.style.position = "fixed";
  input.style.opacity = "0";
  document.body.appendChild(input);
  input.select();
  const copied = document.execCommand("copy");
  input.remove();
  return copied;
}

async function loadPackage(section) {
  const platform = section.dataset.packagePlatform || "windows";
  const architecture = section.dataset.packageArchitecture;
  const detail = section.querySelector("[data-package-detail]");
  const server = section.querySelector("[data-package-server]");
  const name = section.querySelector("[data-package-name]");
  const size = section.querySelector("[data-package-size]");
  const link = section.querySelector("[data-package-link]");
  try {
    const response = await fetch(`/api/client-packages/${platform}/${architecture}`, { cache: "no-store" });
    const data = await response.json();
    server.textContent = data.serverUrl || "-";
    if (!data.available || !data.package) {
      detail.textContent = data.error || "Client package is unavailable.";
      return;
    }
    detail.textContent = `Ready for installation on ${platform} ${architecture}.`;
    name.textContent = `${data.package.target} ${data.package.version}`;
    size.textContent = `${(data.package.length / 1048576).toFixed(1)} MB`;
    link.href = data.package.browserDownloadUrl || data.package.downloadUrl;
    link.target = "_blank";
    link.rel = "noopener";
    link.classList.remove("disabled");
    link.removeAttribute("aria-disabled");
  } catch (error) {
    detail.textContent = "Package status could not be loaded.";
  }
}

function loadDownloads() {
  document.querySelectorAll("[data-package-architecture]").forEach((section) => {
    loadPackage(section);
  });
}

const page = document.body.dataset.page;
document.querySelectorAll("[data-copy-target]").forEach((button) => {
  button.addEventListener("click", () => copyValue(button));
});
document.getElementById("server-relay-form")?.addEventListener("submit", submitServerRelay);
document.getElementById("server-relay-edit-form")?.addEventListener("submit", async (event) => {
  event.preventDefault();
  await submitServerRelayEdit(event.currentTarget);
});
document.getElementById("server-relay-edit-cancel")?.addEventListener("click", closeServerRelayEditDialog);
if (page === "downloads") loadDownloads();
else {
  loadStatus();
  setInterval(loadStatus, 3000);
}
