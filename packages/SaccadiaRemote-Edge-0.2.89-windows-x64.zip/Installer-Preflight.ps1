function Assert-SaccadiaInstallationHost {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $HostName,
        [Parameter(Mandatory = $true)] [string] $Label
    )

    $candidate = $HostName.Trim().TrimStart('[').TrimEnd(']')
    $address = $null
    $isIpAddress = [Net.IPAddress]::TryParse($candidate, [ref] $address)
    $hostType = [Uri]::CheckHostName($candidate)
    if (-not $candidate -or $HostName -match '[\s/\\]' -or
        $HostName.Contains('://') -or
        (-not $isIpAddress -and $hostType -ne [UriHostNameType]::Dns)) {
        throw "$Label must be a DNS name or IP address without a URL scheme or path."
    }
}

function Test-SaccadiaInstallationDns {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $HostName,
        [Parameter(Mandatory = $true)] [string] $Label
    )

    $candidate = $HostName.Trim().TrimStart('[').TrimEnd(']')
    $address = $null
    if ([Net.IPAddress]::TryParse($candidate, [ref] $address)) {
        Write-Host "$Label address check: $candidate is a literal IP address."
        return
    }
    try {
        $resolved = @([Net.Dns]::GetHostAddresses($candidate))
        if ($resolved.Count -eq 0) {
            throw "No addresses were returned."
        }
        Write-Host "$Label DNS check: $candidate resolves to $($resolved[0].IPAddressToString)."
    } catch {
        # DNS may intentionally be configured after the host is installed. Keep
        # this visible to the administrator without preventing that workflow.
        Write-Warning "$Label DNS check failed for '$candidate'. Configure DNS before clients use this node."
    }
}

function Assert-SaccadiaInstallationPorts {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)] [Collections.IDictionary] $Ports)

    $used = @{}
    foreach ($entry in $Ports.GetEnumerator()) {
        $port = [int] $entry.Value
        if ($port -lt 1 -or $port -gt 65535) {
            throw "$($entry.Key) must be in the range 1..65535."
        }
        if ($used.ContainsKey($port)) {
            throw "TCP port $port is assigned to both $($used[$port]) and $($entry.Key)."
        }
        $used[$port] = $entry.Key
    }
}

function Assert-SaccadiaInstallationUri {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $Value,
        [Parameter(Mandatory = $true)] [string] $Scheme,
        [Parameter(Mandatory = $true)] [string] $Label
    )

    $uri = $null
    if (-not [Uri]::TryCreate($Value, [UriKind]::Absolute, [ref] $uri) -or
        $uri.Scheme -cne $Scheme -or [string]::IsNullOrWhiteSpace($uri.Host)) {
        throw "$Label must be an absolute $Scheme URL."
    }
    return $uri
}

function Assert-SaccadiaInstallationPin {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $Pin,
        [Parameter(Mandatory = $true)] [string] $Label
    )

    if ($Pin -notmatch '^[0-9A-Fa-f]{64}$') {
        throw "$Label must contain exactly 64 hexadecimal characters."
    }
}

function Assert-SaccadiaInstallationPfx {
    [CmdletBinding()]
    param(
        [string] $Path,
        [string] $Password,
        [Parameter(Mandatory = $true)] [string] $Role
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return
    }
    $resolved = (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
    $certificate = [Security.Cryptography.X509Certificates.X509Certificate2]::new(
        $resolved,
        $Password,
        [Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    try {
        if (-not $certificate.HasPrivateKey) {
            throw "$Role PFX has no private key."
        }
        $now = [DateTime]::UtcNow
        if ($certificate.NotBefore.ToUniversalTime() -gt $now) {
            throw "$Role PFX is not valid yet."
        }
        if ($certificate.NotAfter.ToUniversalTime() -le $now) {
            throw "$Role PFX is expired."
        }
        Write-Host "$Role certificate check: private key and validity period are usable."
    } finally {
        $certificate.Dispose()
    }
}

function Get-SaccadiaCertificatePlanText {
    [CmdletBinding()]
    param(
        [string] $Path,
        [Parameter(Mandatory = $true)] [string] $DefaultText
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $DefaultText
    }
    return "operator PFX: $([IO.Path]::GetFullPath($Path))"
}

function Confirm-SaccadiaInstallationPlan {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $Title,
        [Parameter(Mandatory = $true)] [string[]] $Details,
        [switch] $ConfirmInstallation
    )

    Write-Host ""
    Write-Host $Title -ForegroundColor Cyan
    foreach ($detail in $Details) {
        Write-Host "  $detail"
    }
    Write-Host ""
    Write-Host "Review DNS, firewall/NAT, certificate ownership, and backup requirements before continuing."
    if ($ConfirmInstallation) {
        Write-Host "Installation plan accepted for unattended installation."
        return
    }

    Write-Host "Type INSTALL to apply this plan and modify the system."
    try {
        $answer = Read-Host "Confirmation"
    } catch {
        throw "Interactive confirmation is unavailable. For deliberate unattended installation, use both -AcceptDisclaimer and -ConfirmInstallation."
    }
    if ($answer -cne "INSTALL") {
        throw "Installation stopped because the installation plan was not confirmed."
    }
}
