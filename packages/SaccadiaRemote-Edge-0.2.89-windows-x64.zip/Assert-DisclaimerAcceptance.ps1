function Assert-SaccadiaDisclaimerAcceptance {
    [CmdletBinding()]
    param(
        [switch] $AcceptDisclaimer,
        [string] $DisclaimerPath = ""
    )

    if ([string]::IsNullOrWhiteSpace($DisclaimerPath)) {
        $packageNotice = Join-Path $PSScriptRoot "DISCLAIMER.md"
        $repositoryNotice = Join-Path $PSScriptRoot "..\PublicGit\DISCLAIMER.md"
        $DisclaimerPath = if (Test-Path -LiteralPath $packageNotice -PathType Leaf) {
            $packageNotice
        } else {
            $repositoryNotice
        }
    }

    if ($AcceptDisclaimer) {
        Write-Host "Disclaimer accepted for unattended installation: the software is installed as-is and at the administrator's risk."
        return
    }

    if (-not (Test-Path -LiteralPath $DisclaimerPath -PathType Leaf)) {
        throw "Installation stopped because DISCLAIMER.md could not be found."
    }

    Write-Host (Get-Content -LiteralPath $DisclaimerPath -Raw)
    Write-Host ""
    Write-Host "Type I ACCEPT to confirm that you have read the disclaimer and accept the possible consequences of installing this software."
    try {
        $answer = Read-Host "Acceptance"
    } catch {
        throw "Interactive acceptance is unavailable. For deliberate unattended installation, review DISCLAIMER.md and use -AcceptDisclaimer."
    }
    if ($answer -cne "I ACCEPT") {
        throw "Installation stopped because the disclaimer was not accepted."
    }

    Write-Host "Disclaimer accepted."
}
