[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run Uninstall-EdgeService.ps1 from an elevated PowerShell session."
}
$serviceName = "SaccadiaRemoteEdgeService"
$service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($service) {
    if ($service.Status -ne "Stopped") {
        Stop-Service -Name $serviceName -Force
        $service.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(20))
    }
    & sc.exe delete $serviceName | Out-Null
}
Get-NetFirewallRule -DisplayName "Saccadia Remote Edge Service" `
    -ErrorAction SilentlyContinue | Remove-NetFirewallRule
Get-ScheduledTask -TaskName "SaccadiaRemoteEdgeCertificateRenewal-*" `
    -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false
Write-Host "EdgeService was removed. ProgramData identities were retained."
