[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string] $ToolPath,
    [Parameter(Mandatory = $true)] [string] $ConfigurationPath,
    [Parameter(Mandatory = $true)] [string] $ServiceName
)

$ErrorActionPreference = "Stop"
$ToolPath = [IO.Path]::GetFullPath($ToolPath)
$ConfigurationPath = [IO.Path]::GetFullPath($ConfigurationPath)
if (-not (Test-Path -LiteralPath $ToolPath -PathType Leaf)) {
    throw "Certificate utility was not found: $ToolPath"
}
if (-not (Test-Path -LiteralPath $ConfigurationPath -PathType Leaf)) {
    throw "Certificate renewal configuration was not found: $ConfigurationPath"
}

$marker = Join-Path ([IO.Path]::GetTempPath()) `
    ("saccadia-cert-" + [Guid]::NewGuid().ToString("N") + ".changed")
try {
    & $ToolPath renew-due --config $ConfigurationPath --changed-marker $marker
    if ($LASTEXITCODE -ne 0) {
        throw "Certificate renewal utility failed with exit code $LASTEXITCODE."
    }
    if (Test-Path -LiteralPath $marker) {
        Restart-Service -Name $ServiceName -Force
        (Get-Service -Name $ServiceName).WaitForStatus(
            "Running",
            [TimeSpan]::FromSeconds(30))
    }
} finally {
    if (Test-Path -LiteralPath $marker) {
        Remove-Item -LiteralPath $marker -Force
    }
}
