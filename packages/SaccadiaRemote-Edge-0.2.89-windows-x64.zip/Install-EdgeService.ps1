[CmdletBinding()]
param(
    [string] $PublishDirectory = "",
    [Parameter(Mandatory = $true)] [string] $NodeId,
    [Parameter(Mandatory = $true)] [string] $SignallingWebSocketUrl,
    [Parameter(Mandatory = $true)] [string] $CoordinatorAddress,
    [Parameter(Mandatory = $true)] [string] $CoordinatorClusterPublicKeyPin,
    [string] $SignallingCertificatePath = "",
    [string] $SignallingCertificatePassword = "",
    [string] $ClusterCertificatePath = "",
    [string] $ClusterCertificatePassword = "",
    [int] $SignallingPort = 5100,
    [switch] $AcceptDisclaimer,
    [switch] $ConfirmInstallation
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Assert-DisclaimerAcceptance.ps1")
. (Join-Path $PSScriptRoot "Installer-Preflight.ps1")
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run Install-EdgeService.ps1 from an elevated PowerShell session."
}
Assert-SaccadiaDisclaimerAcceptance -AcceptDisclaimer:$AcceptDisclaimer
if ([string]::IsNullOrWhiteSpace($PublishDirectory)) {
    # The script is copied into the publish artifact, but also remains runnable
    # from repository scripts/ during development.
    $localExecutable = Join-Path $PSScriptRoot "SaccadiaRemote.EdgeService.exe"
    $PublishDirectory = if (Test-Path -LiteralPath $localExecutable) {
        $PSScriptRoot
    } else {
        Join-Path $PSScriptRoot "..\publish\SaccadiaRemote.EdgeService-win-x64"
    }
}
$PublishDirectory = (Resolve-Path -LiteralPath $PublishDirectory).Path
$serviceExe = Join-Path $PublishDirectory "SaccadiaRemote.EdgeService.exe"
if (-not (Test-Path -LiteralPath $serviceExe)) {
    throw "Edge service executable was not found: $serviceExe"
}

if ($NodeId -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$') {
    throw "NodeId must contain 1..64 letters, digits, dots, underscores, or hyphens."
}
$signallingUri = Assert-SaccadiaInstallationUri $SignallingWebSocketUrl "wss" `
    "SignallingWebSocketUrl"
$coordinatorUri = Assert-SaccadiaInstallationUri $CoordinatorAddress "https" `
    "CoordinatorAddress"
Assert-SaccadiaInstallationPin $CoordinatorClusterPublicKeyPin `
    "CoordinatorClusterPublicKeyPin"
Assert-SaccadiaInstallationPorts ([ordered]@{ "Edge signalling" = $SignallingPort })
Assert-SaccadiaInstallationPfx $SignallingCertificatePath `
    $SignallingCertificatePassword "Edge signalling"
Assert-SaccadiaInstallationPfx $ClusterCertificatePath `
    $ClusterCertificatePassword "Edge cluster"
Test-SaccadiaInstallationDns $signallingUri.Host "Edge"
Test-SaccadiaInstallationDns $coordinatorUri.Host "Coordinator"
$plan = @(
    "Role: additional Edge",
    "Node ID: $NodeId",
    "Public signalling URL: $SignallingWebSocketUrl",
    "Local signalling listener: TCP $SignallingPort",
    "Coordinator cluster endpoint: $CoordinatorAddress",
    "Coordinator pin: $($CoordinatorClusterPublicKeyPin.ToUpperInvariant())",
    "Edge signalling certificate: $(Get-SaccadiaCertificatePlanText $SignallingCertificatePath 'installation-generated or existing identity')",
    "Edge cluster certificate: $(Get-SaccadiaCertificatePlanText $ClusterCertificatePath 'installation-generated or existing identity')",
    "Persistent state: $env:ProgramData\SaccadiaRemote\Edge\$NodeId"
)
Confirm-SaccadiaInstallationPlan "Saccadia Remote Windows Edge installation plan" `
    $plan -ConfirmInstallation:$ConfirmInstallation

$dataRoot = Join-Path $env:ProgramData "SaccadiaRemote\Edge\$NodeId"
$secrets = Join-Path $dataRoot "secrets"
New-Item -ItemType Directory -Path $secrets -Force | Out-Null
$configurationPath = Join-Path $PublishDirectory "appsettings.Production.json"
$existingConfiguration = if (Test-Path -LiteralPath $configurationPath) {
    Get-Content -Raw -LiteralPath $configurationPath | ConvertFrom-Json
} else {
    $null
}
function Assert-UsablePfx {
    param([string] $Path, [string] $Password, [string] $Role)
    $certificate = [Security.Cryptography.X509Certificates.X509Certificate2]::new(
        $Path,
        $Password,
        [Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    try {
        if (-not $certificate.HasPrivateKey) { throw "$Role PFX has no private key." }
        if ($certificate.NotAfter.ToUniversalTime() -le [DateTime]::UtcNow) {
            throw "$Role PFX is expired."
        }
    } finally {
        $certificate.Dispose()
    }
}
function Get-PfxPublicKeyHash {
    param([string] $Path, [string] $Password)
    $certificate = [Security.Cryptography.X509Certificates.X509Certificate2]::new(
        $Path,
        $Password,
        [Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString(
            $sha256.ComputeHash($certificate.GetPublicKey())).Replace("-", "")
    } finally {
        $sha256.Dispose()
        $certificate.Dispose()
    }
}
function Get-EstablishedPfxPassword {
    param([string] $Target, [string] $ConfiguredPassword)
    $sidecar = "$Target.password"
    if (Test-Path -LiteralPath $sidecar) {
        return (Get-Content -Raw -LiteralPath $sidecar).Trim()
    }
    return $ConfiguredPassword
}
function Install-PfxIdentity {
    param(
        [string] $Source,
        [string] $Target,
        [string] $Role,
        [string] $SourcePassword,
        [string] $TargetPassword)
    if (Test-Path -LiteralPath $Target) {
        $sourceHash = Get-PfxPublicKeyHash $Source $SourcePassword
        $targetHash = Get-PfxPublicKeyHash $Target $TargetPassword
        if ($sourceHash -ne $targetHash) {
            throw "Refusing to replace the established $Role key. Restore/import the intended identity or use the explicit certificate-rotation procedure."
        }
    }
    $temporary = "$Target.new-$([Guid]::NewGuid().ToString('N'))"
    try {
        Copy-Item -LiteralPath $Source -Destination $temporary
        Move-Item -LiteralPath $temporary -Destination $Target -Force
    } finally {
        if (Test-Path -LiteralPath $temporary) {
            Remove-Item -LiteralPath $temporary -Force
        }
    }
}
$signallingStorageTarget = Join-Path $secrets "edge-public.pfx"
$clusterStorageTarget = Join-Path $secrets "edge-cluster.pfx"
$signallingTarget = ""
$clusterTarget = ""
if (-not [string]::IsNullOrWhiteSpace($SignallingCertificatePath)) {
    $SignallingCertificatePath = (Resolve-Path -LiteralPath $SignallingCertificatePath).Path
    Assert-UsablePfx $SignallingCertificatePath $SignallingCertificatePassword `
        "EdgeSignallingTLS"
    $oldSignallingPassword = Get-EstablishedPfxPassword $signallingStorageTarget `
        ([string]$existingConfiguration.EdgeSignallingTLS.CertificatePassword)
    Install-PfxIdentity $SignallingCertificatePath $signallingStorageTarget `
        "EdgeSignallingTLS" $SignallingCertificatePassword $oldSignallingPassword
    Set-Content -LiteralPath "$signallingStorageTarget.password" `
        -Value $SignallingCertificatePassword `
        -Encoding UTF8 -NoNewline
    $signallingTarget = $signallingStorageTarget
}
if (-not [string]::IsNullOrWhiteSpace($ClusterCertificatePath)) {
    $ClusterCertificatePath = (Resolve-Path -LiteralPath $ClusterCertificatePath).Path
    Assert-UsablePfx $ClusterCertificatePath $ClusterCertificatePassword "Edge cluster"
    $oldClusterPassword = Get-EstablishedPfxPassword $clusterStorageTarget `
        ([string]$existingConfiguration.EdgeClusterTLS.CertificatePassword)
    Install-PfxIdentity $ClusterCertificatePath $clusterStorageTarget "EdgeClusterTLS" `
        $ClusterCertificatePassword $oldClusterPassword
    Set-Content -LiteralPath "$clusterStorageTarget.password" `
        -Value $ClusterCertificatePassword `
        -Encoding UTF8 -NoNewline
    $clusterTarget = $clusterStorageTarget
}
$aclOutput = & icacls.exe $dataRoot /inheritance:r `
    /grant:r "*S-1-5-18:(OI)(CI)F" `
    "*S-1-5-32-544:(OI)(CI)F" `
    "*S-1-5-19:(OI)(CI)M" 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "Could not secure Edge data: $($aclOutput -join ' ')"
}

$config = @{
    Edge = @{
        NodeId = $NodeId
        CoordinatorAddress = $CoordinatorAddress
        CoordinatorClusterPublicKeyPin = $CoordinatorClusterPublicKeyPin
        ReconnectDelaySec = 3
        HeartbeatIntervalSec = 5
        MaximumConnections = 100000
        MaximumPendingConnections = 1024
        MaximumPendingConnectionsPerIp = 16
        AttachTimeoutSec = 10
    }
    EdgeSignalling = @{
        ListenPort = $SignallingPort
        ClientUrl = $SignallingWebSocketUrl
    }
    EdgeSignallingTLS = @{
        CertificatePath = $signallingTarget
        CertificatePassword = $SignallingCertificatePassword
        CertificateSource = $(if ($signallingTarget) {
            "operator"
        } else { "installation-generated" })
    }
    EdgeClusterTLS = @{
        CertificatePath = $clusterTarget
        CertificatePassword = $ClusterCertificatePassword
        CertificateSource = $(if ($clusterTarget) {
            "operator"
        } else { "installation-generated" })
    }
    Storage = @{ DataDirectory = (Join-Path $dataRoot "data") }
} | ConvertTo-Json -Depth 5
Set-Content -LiteralPath $configurationPath -Value $config -Encoding UTF8
$configAclOutput = & icacls.exe $configurationPath /inheritance:r `
    /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" "*S-1-5-19:R" 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "Could not secure Edge configuration: $($configAclOutput -join ' ')"
}

$serviceName = "SaccadiaRemoteEdgeService"
$existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($existing -and $existing.Status -ne "Stopped") {
    Stop-Service -Name $serviceName -Force
    (Get-Service -Name $serviceName).WaitForStatus("Stopped", [TimeSpan]::FromSeconds(20))
}
if ($existing) {
    & sc.exe config $serviceName binPath= "`"$serviceExe`"" start= auto `
        obj= "NT AUTHORITY\LocalService" | Out-Null
} else {
    & sc.exe create $serviceName binPath= "`"$serviceExe`"" start= auto `
        obj= "NT AUTHORITY\LocalService" DisplayName= "Saccadia Remote Edge" | Out-Null
}
if ($LASTEXITCODE -ne 0) {
    throw "Windows Service Control Manager rejected EdgeService configuration."
}
& sc.exe failure $serviceName reset= 86400 `
    actions= restart/5000/restart/15000/restart/30000 | Out-Null
& sc.exe failureflag $serviceName 1 | Out-Null

$firewallRule = "Saccadia Remote Edge Service"
Get-NetFirewallRule -DisplayName $firewallRule -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule
New-NetFirewallRule -DisplayName $firewallRule -Direction Inbound -Action Allow `
    -Protocol TCP -LocalPort $SignallingPort -Program $serviceExe -Profile Any | Out-Null
Start-Service -Name $serviceName
(Get-Service -Name $serviceName).WaitForStatus("Running", [TimeSpan]::FromSeconds(20))

$renewalConfigurationPath = Join-Path $dataRoot "certificate-renewal.json"
$generatedSecretsRoot = Join-Path $dataRoot "data\secrets"
$signallingRenewalTarget = if ($SignallingCertificatePath) {
    $signallingStorageTarget
} else {
    Join-Path $generatedSecretsRoot "edge-public.pfx"
}
$clusterRenewalTarget = if ($ClusterCertificatePath) {
    $clusterStorageTarget
} else {
    Join-Path $generatedSecretsRoot "edge-cluster.pfx"
}
$renewalConfiguration = @{
    Version = 1
    RenewBeforeDays = 180
    Certificates = @(
        @{
            Role = "EdgeSignallingTLS"
            CertificatePath = $signallingRenewalTarget
            PasswordFile = "$signallingRenewalTarget.password"
            ManifestPath = Join-Path $dataRoot `
                "data\identity\edge-public-certificate.json"
            Source = $(if ($SignallingCertificatePath) {
                "operator"
            } else { "installation-generated" })
            RestartGroup = "edge"
        },
        @{
            Role = "EdgeClusterTLS"
            CertificatePath = $clusterRenewalTarget
            PasswordFile = "$clusterRenewalTarget.password"
            ManifestPath = Join-Path $dataRoot `
                "data\identity\edge-cluster-certificate.json"
            Source = $(if ($ClusterCertificatePath) {
                "operator"
            } else { "installation-generated" })
            RestartGroup = "edge"
        }
    )
}
Set-Content -LiteralPath $renewalConfigurationPath `
    -Value ($renewalConfiguration | ConvertTo-Json -Depth 5) -Encoding UTF8
$renewalAcl = & icacls.exe $renewalConfigurationPath /inheritance:r `
    /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "Could not secure Edge renewal configuration: $($renewalAcl -join ' ')"
}
$renewalTool = Join-Path $PublishDirectory "tools\certificates\saccadia-cert.exe"
$renewalScript = Join-Path $PublishDirectory "Invoke-CertificateRenewal.ps1"
if ((Test-Path -LiteralPath $renewalTool) -and
    (Test-Path -LiteralPath $renewalScript)) {
    $taskArguments = "-NoProfile -ExecutionPolicy Bypass -File `"$renewalScript`" " +
        "-ToolPath `"$renewalTool`" -ConfigurationPath `"$renewalConfigurationPath`" " +
        "-ServiceName `"$serviceName`""
    $action = New-ScheduledTaskAction -Execute "powershell.exe" `
        -Argument $taskArguments
    $trigger = New-ScheduledTaskTrigger -Daily -At "03:00" `
        -RandomDelay (New-TimeSpan -Hours 6)
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable
    Register-ScheduledTask -TaskName "SaccadiaRemoteEdgeCertificateRenewal-$NodeId" `
        -Action $action -Trigger $trigger -Settings $settings -User "SYSTEM" `
        -RunLevel Highest -Force | Out-Null
}

Write-Host "EdgeService is installed. Read https://127.0.0.1:$SignallingPort/api/status for the"
Write-Host "clusterPublicKeyPin and signallingTlsPublicKeyPin to add to Coordinator AllowedEdges."
