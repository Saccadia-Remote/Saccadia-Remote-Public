#!/usr/bin/env bash

# Installation must be an explicit administrator decision. These checks run
# before certificates, persistent directories, firewall-facing containers, or
# systemd units are created. Automated installs opt in through exact values.
saccadia_require_disclaimer_acceptance() {
    if [[ "${SACCADIA_ACCEPT_DISCLAIMER:-}" == "YES" ]]; then
        echo "Disclaimer accepted for unattended installation."
        return 0
    fi

    local package_root repository_root notice found_notice=false
    package_root="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
    repository_root="${package_root}/PublicGit"
    for notice in "${package_root}/DISCLAIMER.md" "${repository_root}/DISCLAIMER.md"; do
        if [[ -f "${notice}" ]]; then
            sed -n '1,220p' "${notice}"
            found_notice=true
            break
        fi
    done
    if [[ "${found_notice}" != "true" ]]; then
        echo "Installation stopped because DISCLAIMER.md could not be found." >&2
        return 1
    fi
    if [[ ! -t 0 ]]; then
        echo "Interactive acceptance is unavailable. For deliberate unattended installation, review DISCLAIMER.md and set SACCADIA_ACCEPT_DISCLAIMER=YES." >&2
        return 1
    fi

    echo
    echo "Type I ACCEPT to confirm that you have read the disclaimer and accept the possible consequences of installing this software."
    read -r -p "Acceptance: " acceptance
    if [[ "${acceptance}" != "I ACCEPT" ]]; then
        echo "Installation stopped because the disclaimer was not accepted." >&2
        return 1
    fi
    echo "Disclaimer accepted."
}

saccadia_confirm_installation_plan() {
    local title="$1"
    shift

    echo
    printf '%s\n' "${title}"
    local detail
    for detail in "$@"; do
        printf '  %s\n' "${detail}"
    done
    echo
    echo "Review DNS, firewall/NAT, certificate ownership, and backup requirements before continuing."
    if [[ "${SACCADIA_CONFIRM_INSTALLATION:-}" == "YES" ]]; then
        echo "Installation plan accepted for unattended installation."
        return 0
    fi
    if [[ ! -t 0 ]]; then
        echo "Interactive confirmation is unavailable. For deliberate unattended installation, set both SACCADIA_ACCEPT_DISCLAIMER=YES and SACCADIA_CONFIRM_INSTALLATION=YES." >&2
        return 1
    fi

    echo "Type INSTALL to apply this plan and modify the system."
    read -r -p "Confirmation: " confirmation
    if [[ "${confirmation}" != "INSTALL" ]]; then
        echo "Installation stopped because the installation plan was not confirmed." >&2
        return 1
    fi
}

saccadia_validate_port() {
    local label="$1" port="$2"
    if [[ ! "${port}" =~ ^[0-9]+$ ]] || (( port < 1 || port > 65535 )); then
        echo "${label} must be in the range 1..65535." >&2
        return 1
    fi
}

saccadia_validate_host() {
    local label="$1" host="$2"
    if [[ -z "${host}" || "${host}" =~ [[:space:]/\\] || "${host}" == *"://"* ]]; then
        echo "${label} must be a DNS name or IP address without a URL scheme or path." >&2
        return 1
    fi
}

saccadia_warn_dns_resolution() {
    local label="$1" host="$2"
    if command -v getent >/dev/null 2>&1; then
        if getent ahosts "${host}" >/dev/null 2>&1; then
            echo "${label} DNS check: ${host} resolves."
        else
            echo "WARNING: ${label} DNS check failed for '${host}'. Configure DNS before clients use this node." >&2
        fi
    else
        echo "WARNING: getent is unavailable; verify ${label} DNS for '${host}' manually." >&2
    fi
}
