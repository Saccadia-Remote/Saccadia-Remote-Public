#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DATA_ROOT="/var/lib/saccadia-remote-edge"
ENV_FILE="${DATA_ROOT}/edge.env"
SERVICE_UID=1654
SERVICE_GID=1654
REQUESTED_SIGNALLING_CERTIFICATE_PATH="${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PATH:-}"
REQUESTED_SIGNALLING_CERTIFICATE_PASSWORD="${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PASSWORD:-}"
REQUESTED_CLUSTER_CERTIFICATE_PATH="${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PATH:-}"
REQUESTED_CLUSTER_CERTIFICATE_PASSWORD="${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PASSWORD:-}"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run this installer as root." >&2
    exit 1
fi
# shellcheck source=accept-disclaimer.sh
source "${SCRIPT_DIR}/accept-disclaimer.sh"
saccadia_require_disclaimer_acceptance
if [[ -f "${ENV_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${ENV_FILE}"
fi
# Releases before the signalling/cluster role split used shorter variable names.
# Preserve existing isolated Edge installations while always preferring the new explicit names.
SACCADIA_EDGE_SIGNALLING_HOST="${SACCADIA_EDGE_SIGNALLING_HOST:-${SACCADIA_EDGE_PUBLIC_HOST:-}}"
SACCADIA_EDGE_SIGNALLING_PORT="${SACCADIA_EDGE_SIGNALLING_PORT:-${SACCADIA_EDGE_PORT:-}}"
SACCADIA_COORDINATOR_CLUSTER_PORT="${SACCADIA_COORDINATOR_CLUSTER_PORT:-${SACCADIA_CLUSTER_PORT:-}}"
ESTABLISHED_SIGNALLING_CERTIFICATE_PASSWORD="${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PASSWORD:-${SACCADIA_CERTIFICATE_PASSWORD:-}}"
ESTABLISHED_CLUSTER_CERTIFICATE_PASSWORD="${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PASSWORD:-${SACCADIA_CERTIFICATE_PASSWORD:-}}"
if [[ -n "${REQUESTED_SIGNALLING_CERTIFICATE_PATH}" ]]; then
    SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PATH="${REQUESTED_SIGNALLING_CERTIFICATE_PATH}"
    if [[ -n "${REQUESTED_SIGNALLING_CERTIFICATE_PASSWORD}" ]]; then
        SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PASSWORD="${REQUESTED_SIGNALLING_CERTIFICATE_PASSWORD}"
    fi
fi
if [[ -n "${REQUESTED_CLUSTER_CERTIFICATE_PATH}" ]]; then
    SACCADIA_EDGE_CLUSTER_CERTIFICATE_PATH="${REQUESTED_CLUSTER_CERTIFICATE_PATH}"
    if [[ -n "${REQUESTED_CLUSTER_CERTIFICATE_PASSWORD}" ]]; then
        SACCADIA_EDGE_CLUSTER_CERTIFICATE_PASSWORD="${REQUESTED_CLUSTER_CERTIFICATE_PASSWORD}"
    fi
fi
: "${SACCADIA_EDGE_SIGNALLING_HOST:?Set SACCADIA_EDGE_SIGNALLING_HOST.}"
: "${SACCADIA_COORDINATOR_HOST:?Set the Coordinator IP or DNS name.}"
: "${SACCADIA_COORDINATOR_CLUSTER_PIN:?Set the Coordinator cluster SPKI pin.}"
command -v docker >/dev/null 2>&1
command -v openssl >/dev/null 2>&1
docker compose version >/dev/null 2>&1

SIGNALLING_HOST="${SACCADIA_EDGE_SIGNALLING_HOST}"
COORDINATOR_HOST="${SACCADIA_COORDINATOR_HOST}"
COORDINATOR_PIN="${SACCADIA_COORDINATOR_CLUSTER_PIN}"
NODE_ID="${SACCADIA_EDGE_NODE_ID:-edge-2}"
EDGE_PORT="${SACCADIA_EDGE_SIGNALLING_PORT:-5100}"
CLUSTER_PORT="${SACCADIA_COORDINATOR_CLUSTER_PORT:-7000}"
CERTIFICATE_PASSWORD="${SACCADIA_CERTIFICATE_PASSWORD:-$(openssl rand -hex 24)}"
SIGNALLING_CERTIFICATE_PASSWORD="${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PASSWORD:-${CERTIFICATE_PASSWORD}}"
CLUSTER_CERTIFICATE_PASSWORD="${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PASSWORD:-${CERTIFICATE_PASSWORD}}"
SIGNALLING_CERTIFICATE_SOURCE="${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_SOURCE:-installation-generated}"
CLUSTER_CERTIFICATE_SOURCE="${SACCADIA_EDGE_CLUSTER_CERTIFICATE_SOURCE:-installation-generated}"

saccadia_validate_host "Edge signalling host" "${SIGNALLING_HOST}"
saccadia_validate_host "Coordinator host" "${COORDINATOR_HOST}"
saccadia_validate_port "Edge signalling port" "${EDGE_PORT}"
saccadia_validate_port "Coordinator cluster port" "${CLUSTER_PORT}"
if [[ "${NODE_ID}" != "${NODE_ID//[^A-Za-z0-9._-]/}" ||
      ! "${NODE_ID}" =~ ^[A-Za-z0-9] || ${#NODE_ID} -gt 64 ]]; then
    echo "Edge node ID must contain 1..64 letters, digits, dots, underscores, or hyphens." >&2
    exit 1
fi
if [[ ! "${COORDINATOR_PIN}" =~ ^[0-9A-Fa-f]{64}$ ]]; then
    echo "Coordinator cluster pin must contain exactly 64 hexadecimal characters." >&2
    exit 1
fi
if [[ -n "${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PATH:-}" ]]; then
    signalling_preflight_source="$(readlink -f "${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PATH}")"
    [[ -f "${signalling_preflight_source}" ]] || {
        echo "Edge signalling PFX was not found: ${signalling_preflight_source}" >&2
        exit 1
    }
    PFX_PASSWORD="${SIGNALLING_CERTIFICATE_PASSWORD}" openssl pkcs12 \
        -in "${signalling_preflight_source}" -passin env:PFX_PASSWORD \
        -noout >/dev/null 2>&1 || {
        echo "Edge signalling PFX or its password is invalid." >&2
        exit 1
    }
    signalling_plan="operator PFX: ${signalling_preflight_source}"
else
    signalling_plan="installation-generated or existing identity"
fi
if [[ -n "${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PATH:-}" ]]; then
    cluster_preflight_source="$(readlink -f "${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PATH}")"
    [[ -f "${cluster_preflight_source}" ]] || {
        echo "Edge cluster PFX was not found: ${cluster_preflight_source}" >&2
        exit 1
    }
    PFX_PASSWORD="${CLUSTER_CERTIFICATE_PASSWORD}" openssl pkcs12 \
        -in "${cluster_preflight_source}" -passin env:PFX_PASSWORD \
        -noout >/dev/null 2>&1 || {
        echo "Edge cluster PFX or its password is invalid." >&2
        exit 1
    }
    cluster_plan="operator PFX: ${cluster_preflight_source}"
else
    cluster_plan="installation-generated or existing identity"
fi
saccadia_warn_dns_resolution "Edge" "${SIGNALLING_HOST}"
saccadia_warn_dns_resolution "Coordinator" "${COORDINATOR_HOST}"
saccadia_confirm_installation_plan \
    "Saccadia Remote Linux Edge installation plan" \
    "Role: additional Edge" \
    "Node ID: ${NODE_ID}" \
    "Public signalling URL: wss://${SIGNALLING_HOST}:${EDGE_PORT}/ws" \
    "Coordinator cluster endpoint: https://${COORDINATOR_HOST}:${CLUSTER_PORT}" \
    "Coordinator pin: ${COORDINATOR_PIN^^}" \
    "Edge signalling certificate: ${signalling_plan}" \
    "Edge cluster certificate: ${cluster_plan}" \
    "Persistent state: ${DATA_ROOT}"

install -d -m 0750 "${DATA_ROOT}"
install -d -o "${SERVICE_UID}" -g "${SERVICE_GID}" -m 0750 "${DATA_ROOT}/data"
install -d -o root -g "${SERVICE_GID}" -m 0750 "${DATA_ROOT}/secrets"

install_supplied_certificate() {
    local configured_path="$1" target="$2" label="$3" source_password="$4" target_password="$5"
    [[ -n "${configured_path}" ]] || return
    [[ -n "${source_password}" ]] || {
        echo "Set the role-specific certificate password for the supplied ${label} PFX." >&2
        exit 1
    }
    local source
    source="$(readlink -f "${configured_path}")"
    [[ -f "${source}" ]] || { echo "${label} PFX was not found: ${source}" >&2; exit 1; }
    if [[ -f "${target}" ]]; then
        local old_pin new_pin
        old_pin="$(pfx_public_key_pin "${target}" "${target_password}")"
        new_pin="$(pfx_public_key_pin "${source}" "${source_password}")"
        if [[ "${old_pin}" != "${new_pin}" ]]; then
            echo "Refusing to replace the established ${label} key." >&2
            exit 1
        fi
    fi
    if [[ "${source}" != "${target}" ]]; then
        local temporary="${target}.new-$$"
        trap 'rm -f -- "${temporary}"' EXIT
        install -o root -g "${SERVICE_GID}" -m 0640 "${source}" "${temporary}"
        mv -f -- "${temporary}" "${target}"
        trap - EXIT
    fi
}

pfx_public_key_pin() {
    local path="$1" password="$2"
    PFX_PASSWORD="${password}" openssl pkcs12 -in "${path}" \
        -passin env:PFX_PASSWORD -nokeys 2>/dev/null |
        openssl x509 -pubkey -noout 2>/dev/null |
        openssl pkey -pubin -outform DER 2>/dev/null |
        openssl dgst -sha256 -hex | awk '{print toupper($2)}'
}

if [[ -n "${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PATH:-}" ]]; then
    [[ -n "${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PASSWORD:-${SACCADIA_CERTIFICATE_PASSWORD:-}}" ]] || {
        echo "Set SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PASSWORD for the supplied Edge signalling PFX." >&2
        exit 1
    }
    install_supplied_certificate "${SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PATH}" \
        "${DATA_ROOT}/secrets/saccadia-edge-public.pfx" "Edge signalling" \
        "${SIGNALLING_CERTIFICATE_PASSWORD}" \
        "${ESTABLISHED_SIGNALLING_CERTIFICATE_PASSWORD:-${CERTIFICATE_PASSWORD}}"
    SIGNALLING_CERTIFICATE_SOURCE="operator"
fi
if [[ -n "${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PATH:-}" ]]; then
    [[ -n "${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PASSWORD:-${SACCADIA_CERTIFICATE_PASSWORD:-}}" ]] || {
        echo "Set SACCADIA_EDGE_CLUSTER_CERTIFICATE_PASSWORD for the supplied Edge cluster PFX." >&2
        exit 1
    }
    install_supplied_certificate "${SACCADIA_EDGE_CLUSTER_CERTIFICATE_PATH}" \
        "${DATA_ROOT}/secrets/saccadia-edge-cluster.pfx" "Edge cluster" \
        "${CLUSTER_CERTIFICATE_PASSWORD}" \
        "${ESTABLISHED_CLUSTER_CERTIFICATE_PASSWORD:-${CERTIFICATE_PASSWORD}}"
    CLUSTER_CERTIFICATE_SOURCE="operator"
fi

create_pfx() {
    local path="$1" common_name="$2" usage="$3" san="$4" password="$5"
    [[ -f "${path}" ]] && return
    local key cert
    key="$(mktemp)"; cert="$(mktemp)"
    openssl req -x509 -newkey rsa:2048 -nodes -days 1825 \
        -subj "/CN=${common_name}" \
        -addext "keyUsage=critical,digitalSignature" \
        -addext "extendedKeyUsage=${usage}" \
        -addext "subjectAltName=${san}" \
        -keyout "${key}" -out "${cert}" >/dev/null 2>&1
    openssl pkcs12 -export -inkey "${key}" -in "${cert}" \
        -out "${path}" -passout "pass:${password}"
    rm -f "${key}" "${cert}"
}
if [[ "${SIGNALLING_HOST}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    EDGE_SAN="IP:${SIGNALLING_HOST},DNS:localhost"
else
    EDGE_SAN="DNS:${SIGNALLING_HOST},DNS:localhost"
fi
create_pfx "${DATA_ROOT}/secrets/saccadia-edge-public.pfx" \
    "Saccadia Remote Edge Signalling" "serverAuth" "${EDGE_SAN}" \
    "${SIGNALLING_CERTIFICATE_PASSWORD}"
create_pfx "${DATA_ROOT}/secrets/saccadia-edge-cluster.pfx" \
    "Saccadia Remote Edge Cluster" "clientAuth" "DNS:${NODE_ID}" \
    "${CLUSTER_CERTIFICATE_PASSWORD}"

EDGE_SIGNALLING_PIN="$(pfx_public_key_pin \
    "${DATA_ROOT}/secrets/saccadia-edge-public.pfx" "${SIGNALLING_CERTIFICATE_PASSWORD}")"
EDGE_CLUSTER_PIN="$(pfx_public_key_pin \
    "${DATA_ROOT}/secrets/saccadia-edge-cluster.pfx" "${CLUSTER_CERTIFICATE_PASSWORD}")"

umask 077
cat > "${ENV_FILE}" <<EOF
SACCADIA_EDGE_NODE_ID=${NODE_ID}
SACCADIA_EDGE_SIGNALLING_HOST=${SIGNALLING_HOST}
SACCADIA_EDGE_SIGNALLING_PORT=${EDGE_PORT}
SACCADIA_COORDINATOR_HOST=${COORDINATOR_HOST}
SACCADIA_COORDINATOR_CLUSTER_PORT=${CLUSTER_PORT}
SACCADIA_COORDINATOR_CLUSTER_PIN=${COORDINATOR_PIN}
SACCADIA_CERTIFICATE_PASSWORD=${CERTIFICATE_PASSWORD}
SACCADIA_EDGE_SIGNALLING_CERTIFICATE_PASSWORD=${SIGNALLING_CERTIFICATE_PASSWORD}
SACCADIA_EDGE_CLUSTER_CERTIFICATE_PASSWORD=${CLUSTER_CERTIFICATE_PASSWORD}
SACCADIA_EDGE_SIGNALLING_CERTIFICATE_SOURCE=${SIGNALLING_CERTIFICATE_SOURCE}
SACCADIA_EDGE_CLUSTER_CERTIFICATE_SOURCE=${CLUSTER_CERTIFICATE_SOURCE}
EOF
printf '%s' "${SIGNALLING_CERTIFICATE_PASSWORD}" > \
    "${DATA_ROOT}/secrets/saccadia-edge-public.pfx.password"
printf '%s' "${CLUSTER_CERTIFICATE_PASSWORD}" > \
    "${DATA_ROOT}/secrets/saccadia-edge-cluster.pfx.password"
cat > "${DATA_ROOT}/certificate-renewal.json" <<EOF
{
  "version": 1,
  "renewBeforeDays": 180,
  "certificates": [
    {
      "role": "EdgeSignallingTLS",
      "certificatePath": "/certificates/saccadia-edge-public.pfx",
      "passwordFile": "/certificates/saccadia-edge-public.pfx.password",
      "manifestPath": "/edge-data/identity/edge-public-certificate.json",
      "source": "${SIGNALLING_CERTIFICATE_SOURCE}",
      "restartGroup": "edge",
      "unixOwnerId": 0,
      "unixGroupId": ${SERVICE_GID},
      "unixManifestOwnerId": ${SERVICE_UID},
      "unixManifestGroupId": ${SERVICE_GID}
    },
    {
      "role": "EdgeClusterTLS",
      "certificatePath": "/certificates/saccadia-edge-cluster.pfx",
      "passwordFile": "/certificates/saccadia-edge-cluster.pfx.password",
      "manifestPath": "/edge-data/identity/edge-cluster-certificate.json",
      "source": "${CLUSTER_CERTIFICATE_SOURCE}",
      "restartGroup": "edge",
      "unixOwnerId": 0,
      "unixGroupId": ${SERVICE_GID},
      "unixManifestOwnerId": ${SERVICE_UID},
      "unixManifestGroupId": ${SERVICE_GID}
    }
  ]
}
EOF
chown root:"${SERVICE_GID}" "${DATA_ROOT}"/secrets/*.pfx
chown root:"${SERVICE_GID}" "${DATA_ROOT}"/secrets/*.password
chmod 0640 "${DATA_ROOT}"/secrets/*.pfx "${DATA_ROOT}"/secrets/*.password
chmod 0600 "${ENV_FILE}"
chmod 0640 "${DATA_ROOT}/certificate-renewal.json"

docker compose --env-file "${ENV_FILE}" -f "${SCRIPT_DIR}/compose.edge.yaml" build --pull
docker compose --env-file "${ENV_FILE}" -f "${SCRIPT_DIR}/compose.edge.yaml" up -d --remove-orphans

if command -v systemctl >/dev/null 2>&1; then
    chmod 0755 "${SCRIPT_DIR}/renew-certificates.sh"
    install -m 0644 "${SCRIPT_DIR}/systemd/saccadia-edge-certificate-renewal.service" \
        /etc/systemd/system/saccadia-edge-certificate-renewal.service
    install -m 0644 "${SCRIPT_DIR}/systemd/saccadia-edge-certificate-renewal.timer" \
        /etc/systemd/system/saccadia-edge-certificate-renewal.timer
    systemctl daemon-reload
    systemctl enable --now saccadia-edge-certificate-renewal.timer
fi

echo "Edge is installed and will retry until Coordinator allows its key."
echo "Add this entry to CoordinatorCluster:AllowedEdges:"
echo "  NodeId: ${NODE_ID}"
echo "  ClusterPublicKeyPin: ${EDGE_CLUSTER_PIN}"
echo "  SignallingWebSocketUrl: wss://${SIGNALLING_HOST}:${EDGE_PORT}/ws"
echo "  SignallingTlsPublicKeyPin: ${EDGE_SIGNALLING_PIN}"
