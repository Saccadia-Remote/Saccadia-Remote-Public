// A capture is fetched only by this button. The ordinary status poll controls
// button availability only and never modifies these pixels or captured data.
(() => {
  const button = document.getElementById("network-map-button");
  if (!button) return;
  const panel = document.getElementById("network-map-panel");
  const caption = document.getElementById("network-map-caption");
  const canvas = document.getElementById("network-map-canvas");
  const summary = document.getElementById("network-map-summary");
  let worldImage;

  function loadWorld() {
    return worldImage ??= new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => { worldImage = undefined; reject(new Error("Map background could not be loaded.")); };
      image.src = "/assets/world-land.svg";
    });
  }

  function drawMarker(context, point) {
    const location = point.location;
    if (!Number.isFinite(location.latitude) || !Number.isFinite(location.longitude) ||
        Math.abs(location.latitude) > 90 || Math.abs(location.longitude) > 180) return;
    const x = (location.longitude + 180) / 360 * canvas.width;
    const y = (90 - location.latitude) / 180 * canvas.height;
    const kind = location.kind;
    const radius = kind === "user" ? 4 : 6;
    context.fillStyle = point.online ? "#48d17b" : "#89939e";
    context.strokeStyle = "#08121b";
    context.lineWidth = 1.5;
    context.beginPath();
    if (kind === "server-relay") context.rect(x - radius, y - radius, radius * 2, radius * 2);
    else if (kind === "edge" || kind === "coordinator") {
      context.moveTo(x, y - radius - 2); context.lineTo(x + radius, y + radius);
      context.lineTo(x - radius, y + radius); context.closePath();
    } else if (kind === "relay") {
      context.moveTo(x, y - radius); context.lineTo(x + radius, y);
      context.lineTo(x, y + radius); context.lineTo(x - radius, y); context.closePath();
    } else context.arc(x, y, radius, 0, Math.PI * 2);
    context.fill(); context.stroke();
  }

  function render(data, world) {
    const context = canvas.getContext("2d");
    context.fillStyle = "#0b1420";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(world, 0, 0, canvas.width, canvas.height);
    const points = Array.isArray(data.points) ? data.points : [];
    // Paint offline markers first, so a live node in the same city stays visible.
    for (const online of [false, true])
      for (const point of points) if (point.online === online) drawMarker(context, point);
    const online = points.filter(point => point.online).length;
    const counts = new Map();
    for (const point of points) counts.set(point.location.kind, (counts.get(point.location.kind) || 0) + 1);
    caption.textContent = `Captured ${new Date(data.capturedAtUtc).toLocaleString()} · ${online} online · ${points.length - online} inactive`;
    summary.textContent = `Users ${counts.get("user") || 0} · Relays ${counts.get("relay") || 0} · ` +
      `Server relays ${counts.get("server-relay") || 0} · Servers ${(counts.get("coordinator") || 0) + (counts.get("edge") || 0)} · ` +
      `Location unknown ${data.unlocated || 0}`;
    canvas.setAttribute("aria-label", `${caption.textContent}. ${summary.textContent}`);
    canvas.hidden = false;
  }

  button.addEventListener("click", async () => {
    if (button.disabled) return;
    button.dataset.loading = "true";
    button.disabled = true;
    panel.hidden = false;
    caption.textContent = "Capturing locations…";
    try {
      const response = await fetch("/api/status/map", { cache: "no-store" });
      if (!response.ok) throw new Error(`Map unavailable (HTTP ${response.status}).`);
      const data = await response.json();
      if (!data.available) {
        button.dataset.available = "false";
        caption.textContent = "GeoIP database is unavailable.";
        return;
      }
      render(data, await loadWorld());
    } catch (error) { caption.textContent = error.message || "Map capture failed."; }
    finally {
      button.dataset.loading = "false";
      button.disabled = button.dataset.available !== "true";
    }
  });
})();
