[CmdletBinding()]
param(
    [string] $PublishDirectory = "$PSScriptRoot\..\publish\SaccadiaRemote.ServerRelayService-win-x64",
    [string] $CoordinatorUrl = "",
    [string] $CoordinatorTlsPublicKeyPin = "",
    [string] $PublicHost = "",
    [int] $RelayPort = 5001,
    [switch] $AcceptDisclaimer,
    [switch] $ConfirmInstallation
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "Assert-DisclaimerAcceptance.ps1")
. (Join-Path $PSScriptRoot "Installer-Preflight.ps1")
Assert-SaccadiaDisclaimerAcceptance -AcceptDisclaimer:$AcceptDisclaimer
$PublishDirectory = (Resolve-Path -LiteralPath $PublishDirectory).Path
$serviceName = "SaccadiaRemoteServerRelayService"
$firewallRule = "Saccadia Remote Server Relay Service"
$serviceExe = Join-Path $PublishDirectory "SaccadiaRemote.ServerRelayService.exe"
if ([string]::IsNullOrWhiteSpace($CoordinatorUrl)) {
    throw "CoordinatorUrl is required."
}
if ([string]::IsNullOrWhiteSpace($PublicHost)) {
    throw "PublicHost is required."
}
Assert-SaccadiaInstallationHost $PublicHost "PublicHost"
Assert-SaccadiaInstallationPorts ([ordered]@{ "Server relay UDP" = $RelayPort })
Confirm-SaccadiaInstallationPlan "Saccadia Remote Windows fallback relay installation plan" `
    @(
        "Role: independently registered server relay",
        "Coordinator: $CoordinatorUrl",
        "Coordinator TLS pin: $(if ([string]::IsNullOrWhiteSpace($CoordinatorTlsPublicKeyPin)) { 'system trust' } else { $CoordinatorTlsPublicKeyPin })",
        "Public relay: ${PublicHost}:$RelayPort/udp",
        "Executable: $serviceExe",
        "Firewall: program-scoped inbound UDP rule",
        "Service account: LocalService"
    ) -ConfirmInstallation:$ConfirmInstallation

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`"",
        "-PublishDirectory", "`"$PublishDirectory`"",
        "-CoordinatorUrl", "`"$CoordinatorUrl`"",
        "-CoordinatorTlsPublicKeyPin", "`"$CoordinatorTlsPublicKeyPin`"",
        "-PublicHost", "`"$PublicHost`"",
        "-RelayPort", "$RelayPort",
        "-AcceptDisclaimer",
        "-ConfirmInstallation"
    )
    $elevated = Start-Process -FilePath "powershell.exe" -Verb RunAs -Wait `
        -PassThru -ArgumentList $arguments
    exit $elevated.ExitCode
}

if (-not (Test-Path -LiteralPath $serviceExe)) {
    throw "Server relay executable was not found: $serviceExe"
}
$appsettings = @{
    Relay = @{
        CoordinatorUrl = $CoordinatorUrl
        CoordinatorTlsPublicKeyPin = $CoordinatorTlsPublicKeyPin
        PublicHost = $PublicHost
        Port = $RelayPort
        Transport = "udp"
        TrafficLimitMbps = 0
    }
}
$appsettings | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $PublishDirectory "appsettings.Production.json") `
        -Encoding utf8

$existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($existing) {
    if ($existing.Status -ne [ServiceProcess.ServiceControllerStatus]::Stopped) {
        Stop-Service -Name $serviceName -Force
        (Get-Service -Name $serviceName).WaitForStatus("Stopped", [TimeSpan]::FromSeconds(15))
    }
    & sc.exe config $serviceName binPath= "`"$serviceExe`"" start= auto `
        obj= "NT AUTHORITY\LocalService" | Out-Null
} else {
    & sc.exe create $serviceName binPath= "`"$serviceExe`"" start= auto `
        obj= "NT AUTHORITY\LocalService" DisplayName= "Saccadia Remote Server Relay" | Out-Null
}
if ($LASTEXITCODE -ne 0) {
    throw "Windows Service Control Manager rejected the server relay configuration."
}

& sc.exe description $serviceName `
    "Forwards encrypted fallback traffic for the local Saccadia Remote server." | Out-Null
& sc.exe failure $serviceName reset= 86400 `
    actions= restart/5000/restart/15000/restart/30000 | Out-Null
& sc.exe failureflag $serviceName 1 | Out-Null

Get-NetFirewallRule -DisplayName $firewallRule -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule
New-NetFirewallRule -DisplayName $firewallRule -Direction Inbound -Action Allow `
    -Protocol UDP -Program $serviceExe -Profile Any | Out-Null

Start-Service -Name $serviceName
(Get-Service -Name $serviceName).WaitForStatus("Running", [TimeSpan]::FromSeconds(15))
Write-Host "Saccadia Remote ServerRelayService is installed and running."
Write-Host "Fingerprint:"
& $serviceExe -fingerprint
