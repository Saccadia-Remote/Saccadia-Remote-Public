[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$serviceName = "SaccadiaRemoteServerRelayService"
$firewallRule = "Saccadia Remote Server Relay Service"
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"")
    $elevated = Start-Process -FilePath "powershell.exe" -Verb RunAs -Wait `
        -PassThru -ArgumentList $arguments
    exit $elevated.ExitCode
}

$service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($service) {
    if ($service.Status -ne [ServiceProcess.ServiceControllerStatus]::Stopped) {
        Stop-Service -Name $serviceName -Force
        $service.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(15))
    }
    & sc.exe delete $serviceName | Out-Null
}
Get-NetFirewallRule -DisplayName $firewallRule -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule
Write-Host "Saccadia Remote ServerRelayService was removed."
